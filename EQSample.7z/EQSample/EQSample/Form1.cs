﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GEM_XGemPro;
using XGem;

namespace EQSample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            Xeqp.Create();
            Xeqp.AddMessage = AddMessage;
            Xeqp.EstablishCommunation.OnCommuncationStateChangeEvent += DisplayCommState;
            Xeqp.RemoteControl.OnReciveS2F41ArgsEvent += OnReciveS2F41HostCommandSend;
            Xeqp.ControlState.OnControlStateChangeEvent += DisplayControlState;
            Xeqp.TerminalServices.OnReciveHostReqTerminalDisplayEvent += OnReciveTerminalServicesEvent;
            Xeqp.EquipmentConstants.OnReciveS2F15Event += OnReciveS2F15NewEcvSend;

            Xeqp.Clock.OnReciveS2F18Event += DisplayS2F18DateTimeData;
            Xeqp.Clock.OnReciveS2F17Event += S2F17DateTimeRequest;
            Xeqp.Clock.OnReciveS2F31Event += S2F31DateTimeSetRequest;

            Xeqp.ProcessProgram.OnReciveS7F2Event += DisplayS7F2PPLoadGrant;
            Xeqp.ProcessProgram.OnReciveS7F4Event += DisplayS7F4ProcessProgramAck;
            Xeqp.ProcessProgram.OnReciveS7F6Event += DisplayS7F6PPData;
            Xeqp.ProcessProgram.OnReciveS7F24Event += DisplayS7F24FmtPPAck;
            Xeqp.ProcessProgram.OnReciveS7F26Event += DisplayS7F26FmtPPData;

            Xeqp.ProcessProgram.OnReciveS7F1Event += DisplayS7F1PPLoadInquire;
            Xeqp.ProcessProgram.OnReciveS7F3Event += DisplayS7F3PPSend;
            Xeqp.ProcessProgram.OnReciveS7F5Event += DisplayS7F5PPRequest;
            Xeqp.ProcessProgram.OnReciveS7F17Event += DisplayS7F17DeletePPSend;
            Xeqp.ProcessProgram.OnReciveS7F19Event += DisplayS7F19CurrentEPPDRequest;
            Xeqp.ProcessProgram.OnReciveS7F23Event += DisplayS7F23FmtPPSend;
            Xeqp.ProcessProgram.OnReciveS7F25Event += DisplayS7F25FmtRequest;

            Xeqp.ProcessProgram.OnReciveS7F28Event += OnReciveS7F28PPVerifyAck;

            Xeqp.Spool.OnSpoolStateChangeEvent += DisplaySpoolState;
        }

        #region Etc...
        private delegate void SetControlTextCallback(Control control, string text);
        private void SetControlText(Control control, string text)
        {
            if (control.InvokeRequired)
            {
                SetControlTextCallback d = new SetControlTextCallback(SetControlText);
                control.BeginInvoke(d, new object[] { control, text });
            }
            else
            {
                control.Text = text;
            }
        }

        private delegate void AddMessageCallBack(string _Message);
        private void AddMessage(string _Message)
        {
            if (this.InvokeRequired)
            {
                AddMessageCallBack d = new AddMessageCallBack(AddMessage);
                this.BeginInvoke(d, _Message);
            }
            else
            {
                lstMsg.Items.Add(DateTime.Now.ToString("[HH:mm:ss fff] ") + _Message);
                if (lstMsg.Items.Count > 100)
                {
                    lstMsg.Items.RemoveAt(0);
                }

                lstMsg.SetSelected(lstMsg.Items.Count - 1, true);
            }
        }

        private void tmrInfo_Tick(object sender, EventArgs e)
        {
            //UpdataOnlineIdentification();
            tbProcessingState.Text = m_eProcessingState.ToString();
        }

        #endregion


        private void btnXGemInitialize_Click(object sender, EventArgs e)
        {
            Xeqp.Initialize(tbCfgFileName.Text);
        }

        private void btnXGemStart_Click(object sender, EventArgs e)
        {
            Xeqp.Start();
            tmrInfo.Enabled = true;
        }

        private void btnXGemStop_Click(object sender, EventArgs e)
        {
            Xeqp.Stop();
            tmrInfo.Enabled = false;
        }

        private void m_btnXGemClose_Click(object sender, EventArgs e)
        {
            Xeqp.Closes();
        }

        private delegate void DisplayCommStateDelgate(object sender, Xeqp.EstablishCommunation.CommuncationStateArgs args);
        private void DisplayCommState(object sender, Xeqp.EstablishCommunation.CommuncationStateArgs args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayCommStateDelgate(DisplayCommState), sender, args);
                return;
            }
            tbCommState.Text = args.StateString;
        }
        private void btnCommunicationEnable_Click(object sender, EventArgs e)
        {
            Xeqp.EstablishCommunation.GEMSetEstablish(true);
        }
        private void btnCommunicationDisable_Click(object sender, EventArgs e)
        {
            Xeqp.EstablishCommunation.GEMSetEstablish(false);
        }


        #region Remote Control
        private delegate void OnReciveS2F41HostCommandSendDelgate(object sender, Xeqp.RemoteControl.S2F41Args args);
        private void OnReciveS2F41HostCommandSend(object sender, Xeqp.RemoteControl.S2F41Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new OnReciveS2F41HostCommandSendDelgate(OnReciveS2F41HostCommandSend), sender, args);
                return;
            }

            string temp = string.Empty;

            temp += "MsgId : " + args.SystemByte.ToString() + "\n";
            temp += "RCMD : " + args.RCMD.ToString() + "\n";
            foreach (KeyValuePair<string, string> t in args.CPVAL)
            {
                temp += t.Key + " = " + t.Value + "\n";
            }

            rtbRcmdParam.Text = temp;
            Dictionary<string, long> CpAck = new Dictionary<string, long>();
            CpAck.Clear(); ;

            Xeqp.RemoteControl.SendS2F42HostCommandAck(args.SystemByte, args.RCMD, 0x00, CpAck);
        } 
        #endregion

        #region OnlineIdentification
        private delegate void DisplayControlStateDelgate(object sender, Xeqp.ControlState.ControlStateArgs args);
        private void DisplayControlState(object sender, Xeqp.ControlState.ControlStateArgs args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayControlStateDelgate(DisplayControlState), sender, args);
                return;
            }
            tbControlState.Text = args.StateString;
        }
        private void btnOffline_Click(object sender, EventArgs e)
        {
            Xeqp.ControlState.ReqOffline();
        }
        private void btnLocal_Click(object sender, EventArgs e)
        {
            Xeqp.ControlState.ReqOnlineLocal();
        }
        private void btnRemote_Click(object sender, EventArgs e)
        {
            Xeqp.ControlState.ReqOnlineRemote();
        }
        private void btnReqHostOffline_Click(object sender, EventArgs e)
        {
            Xeqp.ControlState.ReqHostOffline();
        }

        #endregion

        #region EventNotification
        private void btnSendCEID112_Click(object sender, EventArgs e)
        {
            Dictionary<long, string> _Variable = new Dictionary<long, string>();
            _Variable.Add(1000, "-100");
            _Variable.Add(1001, "1000");
            _Variable.Add(1002, "100000");
            _Variable.Add(1003, "254");
            _Variable.Add(1004, "5000");
            _Variable.Add(1005, "50000");
            _Variable.Add(1006, "10");
            _Variable.Add(1007, "1");
            _Variable.Add(1008, "125.123");
            _Variable.Add(1009, "12345.123456");

            Xeqp.VariableData.SetVariable(_Variable);
            Xeqp.EventNotification.SendS6F11EventReportSend(112);
        }

        private void btnSendCEID113_Click(object sender, EventArgs e)
        {
            List<uint> temp = new List<uint>();
            for (uint i = 0x00; i < 100; i++)
            {
                temp.Add(i);
            }
            Xeqp.VariableData.SetVId1010(temp);
            Xeqp.EventNotification.SendS6F11EventReportSend(113);
        }

        private void btnSendCEID114_Click(object sender, EventArgs e)
        {
            string[] saLotId = new string[25];
            string[] saSubstId = new string[25];
            for (uint i = 0x00; i < 25; i++)
            {
                saLotId[i] = String.Format("LotId{0:00000}", i);
                saSubstId[i] = String.Format("SubstId{0:00000}", i);
            }
            Xeqp.VariableData.SetVId1011(saLotId, saSubstId);

            string sSlotMap = "SlotMap";
            byte[] naSlotId = new byte[25];
            for (byte i = 0x00; i < 25; i++)
            {
                naSlotId[i] = i;
            }
            Xeqp.VariableData.SetVId1012(sSlotMap, naSlotId);
            Xeqp.EventNotification.SendS6F11EventReportSend(114);
        }

        private void btnSetSv_Click(object sender, EventArgs e)
        {
            string Value = tbVid1018.Text;
            Xeqp.VariableData.SetVariable(1018, Value);
            Value = tbVid1019.Text;
            Xeqp.VariableData.SetVariable(1019, Value);
        }

        private void btnSendEvent124_Click(object sender, EventArgs e)
        {
            Xeqp.EventNotification.SendS6F11EventReportSend(124);
        }

        #endregion

        #region Alarm
        private void btnAlarmDetect_Click(object sender, EventArgs e)
        {
            string str = tbALID.Text.Trim();
            long nAlarmID = Convert.ToUInt32(str);

            Xeqp.AlarmManagement.SendS5F1AlarmReportSend(nAlarmID, true);

        }

        private void btnAlarmClear_Click(object sender, EventArgs e)
        {
            string str = tbALID.Text.Trim();
            long nAlarmID = Convert.ToUInt32(str);

            Xeqp.AlarmManagement.SendS5F1AlarmReportSend(nAlarmID, false);
        } 
        #endregion

        #region Terminal Services
        private void mbtnTerminalMessageSend_Click(object sender, EventArgs e)
        {
            long tid = Convert.ToInt64(tbTermialMessageTID.Text);
            string msg = tbSendTermialMessage.Text;

            Xeqp.TerminalServices.SendS10F1TerminalRequest(tid, msg);
        }

        //Host 要求螢幕顯示信息
        delegate void OnReciveTerminalServicesReciveEventDelgate(object sender, Xeqp.TerminalServices.TerminalDisplayArgs args);
        private void OnReciveTerminalServicesEvent(object sender, Xeqp.TerminalServices.TerminalDisplayArgs args)
        {
            if (InvokeRequired)
            {
                Invoke(new OnReciveTerminalServicesReciveEventDelgate(OnReciveTerminalServicesEvent), sender, args);
                return;
            }

            tbMessageFromHost.Text = args.TID.ToString() + "\r\n";

            string Message = string.Empty;
            foreach (string str in args.Messages)
            {
                Message += str + "\r\n";
            }
            tbMessageFromHost.Text = Message;
        } 
        #endregion

        #region Equipment Constants
        private void btnSetECV_Click(object sender, EventArgs e)
        {
            Dictionary<long, string> Ecv = new Dictionary<long, string>();
            long Key = Convert.ToInt64(tbECID.Text);
            string Value = tbECV.Text;
            Ecv.Add(Key, Value);
            Xeqp.EquipmentConstants.SetEcvChangde(Ecv);
        }

        private void btnGetECV_Click(object sender, EventArgs e)
        {
            long ECID = Convert.ToInt64(tbECID.Text);
            string Value = string.Empty;
            tbECV.Text = Value;
            Xeqp.EquipmentConstants.GetEcv(ECID, ref Value);
            tbECV.Text = Value;
        }

        // Host 更新 EC
        delegate void OnReciveS2F15NewEcvSendDelgate(object sender, Xeqp.EquipmentConstants.S2F15Args args);
        private void OnReciveS2F15NewEcvSend(object sender, Xeqp.EquipmentConstants.S2F15Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new OnReciveS2F15NewEcvSendDelgate(OnReciveS2F15NewEcvSend), sender, args);
                return;
            }

            string temp = string.Empty;
            foreach (var EC in args.Ecv)
            {
                temp += "ID :" + EC.Key + " = ";
                temp += EC.Value + "\n\r";
            }
            rtbNewEcv.Text = temp;

            Xeqp.EquipmentConstants.SendS2F16NewEcvAck(args.SystemByte, 0);
        } 
        #endregion

        #region Variable
        private void btnSetVariable_Click(object sender, EventArgs e)
        {
            long _Vid = Convert.ToInt64(tbVid.Text);
            string _Value = tbVariableValue.Text;
            Xeqp.VariableData.SetVariable(_Vid, _Value);
        }
        private void btnGetSv_Click(object sender, EventArgs e)
        {
            long _Vid = Convert.ToInt64(tbVid.Text);
            string _Value = string.Empty;
            tbVariableValue.Text = _Value;
            Xeqp.VariableData.GetVariable(_Vid, ref _Value);
            tbVariableValue.Text = _Value;
        }
        private void btnSetVariableByName_Click(object sender, EventArgs e)
        {
            string _Vid = tbVidName.Text;
            string _Value = tbVariableValue.Text;
            Xeqp.VariableData.SetVariable(_Vid, _Value);
        } 
        #endregion

        #region Processing State...
        //   Processing state for sample(equipment dependent)
        enum _eProcessingState
        {
            None = -1,
            SystemPowerUp = 1,
            Empty,
            Idle,
            Standby,
            Processing,
            HoldProcessing
        }
        _eProcessingState m_eProcessingState = _eProcessingState.None;
        private void btnProcessingState_Click(object sender, EventArgs e)
        {
            long nIndex = 0;
            long nState = 0;
            string szState;

            nIndex = m_cmbProcessingState.SelectedIndex;
            if (nIndex == -1) { return; }
            szState = m_cmbProcessingState.Text;

            szState = szState.Substring(0, szState.IndexOf("-") - 1);
            long.TryParse(szState, out nState);
            SetProcessingState((_eProcessingState)nState);
        }

        private void SetProcessingState(_eProcessingState eState)
        {
            long nCeid = 0;

            if (m_eProcessingState == eState) { return; }

            // 1. setting status variable.
            // ProcessingState와 PreviousProcessingState 이외에도 이 이벤트에 필요한 Variable을 설정할 수 있으며
            // Event 보내기 전에 Setting을 먼저 하도록 한다.
            // Processing State
            Xeqp.VariableData.SetVariable(6, String.Format("{0}", (int)eState));
            Xeqp.VariableData.SetVariable(7, String.Format("{0}", (int)m_eProcessingState));

            // 2. send event for transition.
            //State Transition 1
            if ((m_eProcessingState == _eProcessingState.SystemPowerUp) && (eState == _eProcessingState.Empty))
            {
                nCeid = 101;
            }
            //State Transition 2
            else if ((m_eProcessingState == _eProcessingState.Empty) && (eState == _eProcessingState.Idle))
            {
                nCeid = 102;
            }
            //State Transition 3
            else if ((m_eProcessingState == _eProcessingState.Idle) && (eState == _eProcessingState.Standby))
            {
                nCeid = 103;
            }
            //State Transition 4
            else if ((m_eProcessingState == _eProcessingState.Standby) && (eState == _eProcessingState.Processing))
            {
                nCeid = 104;
            }
            //State Transition 5
            else if ((m_eProcessingState == _eProcessingState.Standby) && (eState == _eProcessingState.Idle))
            {
                nCeid = 105;
            }
            //State Transition 6
            else if ((m_eProcessingState == _eProcessingState.Processing) && (eState == _eProcessingState.HoldProcessing))
            {
                nCeid = 106;
            }
            //State Transition 7
            else if ((m_eProcessingState == _eProcessingState.Processing) && (eState == _eProcessingState.Idle))
            {
                nCeid = 107;
            }
            //State Transition 8
            else if ((m_eProcessingState == _eProcessingState.Processing) && (eState == _eProcessingState.Standby))
            {
                nCeid = 108;
            }
            //State Transition 9
            else if ((m_eProcessingState == _eProcessingState.HoldProcessing) && (eState == _eProcessingState.Processing))
            {
                nCeid = 109;
            }
            //State Transition 10
            else if ((m_eProcessingState == _eProcessingState.HoldProcessing) && (eState == _eProcessingState.Standby))
            {
                nCeid = 110;
            }
            //State Transition 11
            else if ((m_eProcessingState == _eProcessingState.HoldProcessing) && (eState == _eProcessingState.Idle))
            {
                nCeid = 111;
            }
            else
            {
                m_eProcessingState = eState;
                return;
            }

            m_eProcessingState = eState;

            Xeqp.EventNotification.SendS6F11EventReportSend(nCeid);
        }
        #endregion

        #region PP
        private void btnSetPPChanged_Click(object sender, EventArgs e)
        {
            long nMode = 0;
            string sPpid = "";
            byte[] psBody = new byte[10];

            //nMode : 1(Created), 2(Edited), 3(Deleted)
            nMode = 1;
            sPpid = "PPID001";
            psBody[0] = (byte)'a';
            psBody[1] = (byte)'b';
            psBody[2] = (byte)'c';
            psBody[3] = (byte)'1';
            psBody[4] = (byte)'2';
            psBody[5] = (byte)'3';

            Xeqp.ProcessProgram.SetPPChanged(nMode, sPpid, psBody);
        }

        private void btnSetPPFmtChanged_Click(object sender, EventArgs e)
        {
            long nMode = 1;
            string sPpid = "PPID001";
            string sMdln = "Mdln";
            string sSoftRev = "Rev001";

            string Codes = string.Empty;

            Dictionary<string, List<string>> Body = new Dictionary<string, List<string>>();
            Codes = "1";
            List<string> Temp1 = new List<string>();
            Temp1.Add("Param001");
            Temp1.Add("Param002");
            Temp1.Add("Param003");
            Temp1.Add("Param004");
            Temp1.Add("Param005");
            Body.Add(Codes, Temp1);

            Codes = "2";
            List<string> Temp2 = new List<string>();
            Temp2.Add("Param006");
            Temp2.Add("Param007");
            Temp2.Add("Param008");
            Temp2.Add("Param009");
            Temp2.Add("Param010");
            Body.Add(Codes, Temp2);

            Xeqp.ProcessProgram.SetPPChanged(nMode, sPpid, sMdln, sSoftRev, Body);
        }

        private void btnSendS7F1PPLoadInquire_Click(object sender, EventArgs e)
        {
            string sPpid = "";
            long nLength = 0;

            sPpid = "PPID001";
            nLength = 10000;

            Xeqp.ProcessProgram.SendS7F1ProcessProgramLoadInquire(sPpid, nLength);
        }

        private void btnSendS7F27PPFmtVerification_Click(object sender, EventArgs e)
        {
            string sPpid = "";
            long nCount = 0;
            long[] naAck = new long[2];
            string[] saSeqNo = new string[2];
            string[] saError = new string[2];

            sPpid = "PPID001";
            nCount = 2;
            naAck[0] = 10; naAck[1] = 11;
            saSeqNo[0] = "1000"; saSeqNo[1] = "1001";
            saError[0] = "error1"; saError[1] = "error2";

            Xeqp.ProcessProgram.SendS7F27PPVerifySend(sPpid, nCount, naAck, saSeqNo, saError);
        }

        private delegate void DisplayS7F2PProcessProgramLoadGrantDelgate(object sender, Xeqp.ProcessProgram.S7F2Args args);
        private void DisplayS7F2PPLoadGrant(object sender, Xeqp.ProcessProgram.S7F2Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F2PProcessProgramLoadGrantDelgate(DisplayS7F2PPLoadGrant), sender, args);
                return;
            }
            rtbPP.Text = "PPGNT = " + args.PPGNT;
        }

        private void btnSendS7F3PPSend_Click(object sender, EventArgs e)
        {
            string sPpid = "PPID001";
            char[] Body = "Body0".ToArray();
            byte[] psBody = new byte[Body.Length];

            for (int i = 0x00; i < Body.Length; i++)
            {
                psBody[i] = (byte)Body[i];
            }

            //psBody[0] = (byte)'B';
            //psBody[1] = (byte)'o';
            //psBody[2] = (byte)'d';
            //psBody[3] = (byte)'y';
            //psBody[4] = (byte)'0';

            Xeqp.ProcessProgram.SendS7F3ProcessProgramSend(sPpid, psBody);
        }
        private delegate void DisplayS7F4ProcessProgramAckDelgate(object sender, Xeqp.ProcessProgram.S7F4Args args);
        private void DisplayS7F4ProcessProgramAck(object sender, Xeqp.ProcessProgram.S7F4Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F4ProcessProgramAckDelgate(DisplayS7F4ProcessProgramAck), sender, args);
                return;
            }
            rtbPP.Text = "ACKC7 = " + args.ACKC7;
        }

        private void btnSendS7F5PPRequest_Click(object sender, EventArgs e)
        {
            string sPpid = "";
            sPpid = "PPID001";
            Xeqp.ProcessProgram.SendS7F5ProcessProgramRequest(sPpid);
        }
        private delegate void DisplayS7F6ProcessProgramDataDelgate(object sender, Xeqp.ProcessProgram.S7F6Args args);
        private void DisplayS7F6PPData(object sender, Xeqp.ProcessProgram.S7F6Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F6ProcessProgramDataDelgate(DisplayS7F6PPData), sender, args);
                return;
            }
            rtbPP.Text = args.Body;
        }

        private void btnSendS7F23FmtPPSend_Click(object sender, EventArgs e)
        {
            string sPpid = "PPID001";
            string sMdln = "EQP1";
            string sSoftRev = "V1.1";
            string Codes = string.Empty;

            Dictionary<string, List<string>> Body = new Dictionary<string, List<string>>();
            Codes = "1";
            List<string> Temp1 = new List<string>();
            Temp1.Add("Param001");
            Temp1.Add("Param002");
            Temp1.Add("Param003");
            Temp1.Add("Param004");
            Temp1.Add("Param005");
            Body.Add(Codes, Temp1);

            Codes = "2";
            List<string> Temp2 = new List<string>();
            Temp2.Add("Param006");
            Temp2.Add("Param007");
            Temp2.Add("Param008");
            Temp2.Add("Param009");
            Temp2.Add("Param010");
            Body.Add(Codes, Temp2);

            Xeqp.ProcessProgram.SendS7F23FormattedProcessProgramSend(sPpid, sMdln, sSoftRev, Body);
        }
        private delegate void DisplayS7F24FormattedProcessProgramAckDelgate(object sender, Xeqp.ProcessProgram.S7F24Args args);
        private void DisplayS7F24FmtPPAck(object sender, Xeqp.ProcessProgram.S7F24Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F24FormattedProcessProgramAckDelgate(DisplayS7F24FmtPPAck), sender, args);
                return;
            }
            rtbPP.Text = "S7F24\n";
            rtbPP.Text += "ACKC7 = " + args.ACKC7;
        }

        private void btnSendS7F25FmtPPRequest_Click(object sender, EventArgs e)
        {
            string sPpid = "PPID001";
            Xeqp.ProcessProgram.SendS7F25FormattedProcessProgramRequest(sPpid);
        }
        private delegate void DisplayS7F26FmtPPDataDelgate(object sender, Xeqp.ProcessProgram.S7F26Args args);
        private void DisplayS7F26FmtPPData(object sender, Xeqp.ProcessProgram.S7F26Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F26FmtPPDataDelgate(DisplayS7F26FmtPPData), sender, args);
                return;
            }
            string str = string.Empty;
            str += "Ppid = " + args.Ppid + "\n";
            str += "sMdln = " + args.sMdln + "\n";
            str += "sSoftRev = " + args.sSoftRev + "\n";

            foreach (KeyValuePair<string, List<string>> _KeyValuePair in args.Body)
            {
                str += "Code" + _KeyValuePair.Key + "\n";
                foreach (string tem in _KeyValuePair.Value)
                {
                    str += tem + "\n";
                }
            }

            rtbPP.Text = str;
        }

        private delegate void DisplayS7F1PPLoadInquireDelgate(object sender, Xeqp.ProcessProgram.S7F1Args args);
        private void DisplayS7F1PPLoadInquire(object sender, Xeqp.ProcessProgram.S7F1Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F1PPLoadInquireDelgate(DisplayS7F1PPLoadInquire), sender, args);
                return;
            }
            rtbPP.Text = "PPid = " + args.sPpid;

            Xeqp.ProcessProgram.SendS7F2ProcessProgramLoadGrant(args.SystemByte, args.sPpid, 0);
        }

        private delegate void DisplayS7F3PPSendDelgate(object sender, Xeqp.ProcessProgram.S7F3Args args);
        private void DisplayS7F3PPSend(object sender, Xeqp.ProcessProgram.S7F3Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F3PPSendDelgate(DisplayS7F3PPSend), sender, args);
                return;
            }
            string str = string.Empty;
            str += "S7F3\n";
            str += "nMsgId = " + args.SystemByte + "\n";
            str += "PPid = " + args.sPpid + "\n";
            str += "Body = " + args.Body + "\n";
            rtbPP.Text = str;

            Xeqp.ProcessProgram.SendS7F4ProcessProgramAck(args.SystemByte, args.sPpid, 0x00);
        }

        private delegate void DisplayS7F5PPRequestDelgate(object sender, Xeqp.ProcessProgram.S7F5Args args);
        private void DisplayS7F5PPRequest(object sender, Xeqp.ProcessProgram.S7F5Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F5PPRequestDelgate(DisplayS7F5PPRequest), sender, args);
                return;
            }
            string str = string.Empty;
            str += "nMsgId = " + args.SystemByte + "\n";
            str += "PPid = " + args.sPpid + "\n";
            rtbPP.Text += str;

            string sBody = "PPbody";
            Xeqp.ProcessProgram.SendS7F6ProcessProgramData(args.SystemByte, args.sPpid, sBody);
        }

        private delegate void DisplayS7F17DeletePPSendDelgate(object sender, Xeqp.ProcessProgram.S7F17Args args);
        private void DisplayS7F17DeletePPSend(object sender, Xeqp.ProcessProgram.S7F17Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F17DeletePPSendDelgate(DisplayS7F17DeletePPSend), sender, args);
                return;
            }
            string str = string.Empty;
            str += "nMsgId = " + args.SystemByte + "\n";
            foreach (string id in args.psPpid)
            {
                str += "psPpid = " + id + "\n";
            }

            rtbPP.Text = str;
            Xeqp.ProcessProgram.SendS7F18DeleteProcessProgramAck(args.SystemByte, args.psPpid, 0x00);
        }

        private delegate void DisplayS7F19CurrentEPPDRequestDelgate(object sender, Xeqp.ProcessProgram.S7F19Args args);
        private void DisplayS7F19CurrentEPPDRequest(object sender, Xeqp.ProcessProgram.S7F19Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F19CurrentEPPDRequestDelgate(DisplayS7F19CurrentEPPDRequest), sender, args);
                return;
            }

            string str = string.Empty;
            str += "S7F19\n";
            str += "nMsgId = " + args.nSystemByte + "\n";
            rtbPP.Text = str;
            string[] saPpids = new string[2];
            saPpids[0] = "PPID001";
            saPpids[1] = "PPID002";
            Xeqp.ProcessProgram.SendS7F20CurrentEPPDRequest(args.nSystemByte, saPpids);
        }


        private delegate void DisplayS7F23FmtPPSendDelgate(object sender, Xeqp.ProcessProgram.S7F23Args args);
        private void DisplayS7F23FmtPPSend(object sender, Xeqp.ProcessProgram.S7F23Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F23FmtPPSendDelgate(DisplayS7F23FmtPPSend), sender, args);
                return;
            }

            string str = string.Empty;
            str += "S7F23\n";
            str += "Ppid = " + args.sPpid + "\n";
            str += "sMdln = " + args.sMdln + "\n";
            str += "sSoftRev = " + args.sSoftRev + "\n";

            foreach (KeyValuePair<string, List<string>> _KeyValuePair in args.Body)
            {
                str += "Code = " + _KeyValuePair.Key + "\n";
                foreach (string tem in _KeyValuePair.Value)
                {
                    str += tem + "\n";
                }
            }

            rtbPP.Text = str;

            Xeqp.ProcessProgram.SendS7F24FormattedProcessProgramAck(args.SystemByte, args.sPpid, 0x00);
        }

        private delegate void DisplayS7F25FmtRequestDelgate(object sender, Xeqp.ProcessProgram.S7F25Args args);
        private void DisplayS7F25FmtRequest(object sender, Xeqp.ProcessProgram.S7F25Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS7F25FmtRequestDelgate(DisplayS7F25FmtRequest), sender, args);
                return;
            }

            string str = string.Empty;
            str += "nMsgId = " + args.SystemByte + "\n";
            str += "sPpid = " + args.sPpid + "\n";
            rtbPP.Text = str;

            string sMdln = "Mdln";
            string sSoftRev = "Ver001";

            Dictionary<string, List<string>> Body = new Dictionary<string, List<string>>();
            List<string> Temp1 = new List<string>();
            Temp1.Add("Param001");
            Temp1.Add("Param002");
            Temp1.Add("Param003");
            Temp1.Add("Param004");
            Temp1.Add("Param005");
            Body.Add("1", Temp1);
            List<string> Temp2 = new List<string>();
            Temp2.Add("Param006");
            Temp2.Add("Param007");
            Temp2.Add("Param008");
            Temp2.Add("Param009");
            Temp2.Add("Param010");
            Body.Add("2", Temp2);

            Xeqp.ProcessProgram.SendS7F26FormattedProcessProgramData(args.SystemByte, args.sPpid, sMdln, sSoftRev, Body);
        }

        private delegate void OnReciveS7F28PPVerifyAckDelgate(object sender, Xeqp.ProcessProgram.S7F28Args args);
        private void OnReciveS7F28PPVerifyAck(object sender, Xeqp.ProcessProgram.S7F28Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new OnReciveS7F28PPVerifyAckDelgate(OnReciveS7F28PPVerifyAck), sender, args);
                return;
            }

            string str = string.Empty;
            str += "sPpid = " + args.sPpid + "\n";
            str += "nResult = " + args.nResult + "\n";
            rtbPP.Text = str;
        } 
        #endregion

        #region Clock
        private void btnReqHostGetDateTime_Click(object sender, EventArgs e)
        {
            Xeqp.Clock.SendS2F17RDateTimeRequest();
        }

        private delegate void DisplayS2F18DateTimeDataDelgate(object sender, Xeqp.Clock.S2F18Args args);
        private void DisplayS2F18DateTimeData(object sender, Xeqp.Clock.S2F18Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplayS2F18DateTimeDataDelgate(DisplayS2F18DateTimeData), sender, args);
                return;
            }
            rtbClock.Text = "S2F18\n";
            rtbClock.Text += args.SystemTime;
        }

        private delegate void S2F17DateTimeRequestDelgate(object sender, Xeqp.Clock.S2F17Args args);
        private void S2F17DateTimeRequest(object sender, Xeqp.Clock.S2F17Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new S2F17DateTimeRequestDelgate(S2F17DateTimeRequest), sender, args);
                return;
            }
            rtbClock.Text = "S2F17\n";
            rtbClock.Text += args.nMsgId +"S2F17\n";
            string sSystemTime = DateTime.Now.ToString("yyyyMMddHHmmss00");
            Xeqp.Clock.SendS2F18DateTimeData(args.nMsgId, sSystemTime);
        }

        private delegate void S2F31DateTimeSetRequestDelgate(object sender, Xeqp.Clock.S2F31Args args);
        private void S2F31DateTimeSetRequest(object sender, Xeqp.Clock.S2F31Args args)
        {
            if (InvokeRequired)
            {
                Invoke(new S2F31DateTimeSetRequestDelgate(S2F31DateTimeSetRequest), sender, args);
                return;
            }
            rtbClock.Text = args.SystemTime;
            Xeqp.Clock.SendS2F32DateTimeSetAck(args.nMsgId, 0);
        }
        
        #endregion

        #region Spool
        private delegate void DisplaySpoolStateDelgate(object sender, Xeqp.Spool.SpoolStateArgs args);
        private void DisplaySpoolState(object sender, Xeqp.Spool.SpoolStateArgs args)
        {
            if (InvokeRequired)
            {
                Invoke(new DisplaySpoolStateDelgate(DisplaySpoolState), sender, args);
                return;
            }
            string str = "State = " + args.State + "\n";
            str += "LoadState = " + args.LoadState + "\n";
            str += "UnloadState = " + args.UnloadState + "\n";
            str += "FullTime = " + args.FullTime + "\n";
            str += "MaxTransmit = " + args.MaxTransmit + "\n";
            str += "MsgNum = " + args.MsgNum + "\n";
            str += "TotalNum = " + args.TotalNum + "\n";
            str += "TotalNum = " + args.TransmitFail + "\n";
            rtbSpooling.Text = str;
        } 
        #endregion


        private void btnS101F101_Click(object sender, EventArgs e)
        {
            Xeqp.Userdefinedmessage.SendS101F101();

        }
        private void btnS101F103_Click(object sender, EventArgs e)
        {
            Xeqp.Userdefinedmessage.SendS101F103();
        }

        private void lstMsg_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            lstMsg.Items.Clear();
        }

        private void tbSetVid33_Click(object sender, EventArgs e)
        {
            string value = tbVid33.Text;
            Xeqp.VariableData.SetVariable(33, value);
        }

        private void tbSendCeid11_Click(object sender, EventArgs e)
        {
            Xeqp.EventNotification.SendS6F11EventReportSend(11);
        }

        private void tbSendCeid12_Click(object sender, EventArgs e)
        {
            Xeqp.EventNotification.SendS6F11EventReportSend(12);
        }

        

        

        

       
        

        

        

        
        
    }
}
