﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GEM_XGemPro;

namespace XGem
{
    class Xeqp
    {

        private static XGemProNet mXGem = null;

        public static void Create()
        {
            mXGem = new XGemProNet();
            // Link XGemEventHandler...
            // XGEM 發生錯誤時
            mXGem.OnGEMErrorEvent += new OnGEMErrorEvent(OnGEMErrorEvent);
            // XGEM 本身的狀態改變時
            mXGem.OnXGEMStateEvent += new OnXGEMStateEvent(OnXGEMStateEvent);
            //自訂STREAM FUNCTIN 收到
            mXGem.OnSECSMessageReceived += new OnSECSMessageReceived(OnSECSMessageReceived);
            mXGem.OnGEMSecondaryMsgReceived += new OnGEMSecondaryMsgReceived(OnGEMSecondaryMsgReceived);
            //Spool 狀態改變時
            mXGem.OnGEMSpoolStateChanged += new OnGEMSpoolStateChanged(Spool.OnGEMSpoolStateChanged);
            //CommState 狀態改變時
            mXGem.OnGEMCommStateChanged += new OnGEMCommStateChanged(EstablishCommunation.OnGEMCommStateChanged);
            //ControlState 狀態改變時
            mXGem.OnGEMControlStateChanged += new OnGEMControlStateChanged(ControlState.OnControlStateChanged);
            //收到HOST 要求OFF LINE時
            mXGem.OnGEMReqOffline += new OnGEMReqOffline(ControlState.OnReciveS1F15HostRequestOffline);
            //收到HOST 要求ON LINE時
            mXGem.OnGEMReqOnline += new OnGEMReqOnline(ControlState.OnReciveS1F17HostRequestOnline);

            //收到HOST 要求 修改EC 
            mXGem.OnGEMReqChangeECV += new OnGEMReqChangeECV(EquipmentConstants.OnReciveS2F15NewEcvSend);
            //修改 EC 後回報
            mXGem.OnGEMECVChanged += new OnGEMECVChanged(EquipmentConstants.OnGEMECVChanged);

            //收到 HOST 要求 EQ 時間時
            mXGem.OnGEMReqGetDateTime += new OnGEMReqGetDateTime(Clock.OnReciveS2F17DateTimeRequest);
            //收到 HOST 回復 EQ 查詢 時間時
            mXGem.OnGEMRspGetDateTime += new OnGEMRspGetDateTime(Clock.OnReciveS2F18DateTimeData);
            //收到 HOST 要求 EQ 修改時間時
            mXGem.OnGEMReqDateTime += new OnGEMReqDateTime(Clock.OnReciveS2F31DateTimeSetRequest);

            //收到 HOST 的 RemoteCommand
            mXGem.OnGEMReqRemoteCommand += new OnGEMReqRemoteCommand(RemoteControl.OnReciveS2F41HostCommandSend);

            //收到 HOST 的 PPLoadInquire 
            mXGem.OnGEMReqPPLoadInquire += new OnGEMReqPPLoadInquire(ProcessProgram.OnReciveS7F1ProcessProgramLoadInquire);
            //收到 HOST 回覆 PPLoadInquire 
            mXGem.OnGEMRspPPLoadInquire += new OnGEMRspPPLoadInquire(ProcessProgram.OnReciveS7F2ProcessProgramLoadGrant);
            //收到 HOST 的 PP 傳送
            mXGem.OnGEMReqPPSend += new OnGEMReqPPSend(ProcessProgram.OnReciveS7F3ProcessProgramSend);
            //收到 HOST 的 PP 傳送回覆
            mXGem.OnGEMRspPPSend += new OnGEMRspPPSend(ProcessProgram.OnReciveS7F4ProcessProgramAck);
            //收到 HOST 的要求 PP 上傳
            mXGem.OnGEMReqPP += new OnGEMReqPP(ProcessProgram.OnReciveS7F5ProcessProgramRequest);
            //收到 HOST 的回覆 PP 下傳
            mXGem.OnGEMRspPP += new OnGEMRspPP(ProcessProgram.OnReciveS7F6ProcessProgramData);
            //收到 HOST 的要求 PP 刪除
            mXGem.OnGEMReqPPDelete += new OnGEMReqPPDelete(ProcessProgram.OnReciveS7F17DeleteProcessProgramSend);
            //收到 HOST 的要求 PP LIST
            mXGem.OnGEMReqPPList += new OnGEMReqPPList(ProcessProgram.OnReciveS7F19CurrentEPPDRequest);

            //收到 HOST 的 Fmt PP 傳送
            mXGem.OnGEMReqPPFmtSend += new OnGEMReqPPFmtSend(ProcessProgram.OnReciveS7F23FormattedProcessProgramSend);
            //收到 HOST 的 Fmt PP 傳送回覆
            mXGem.OnGEMRspPPFmtSend += new OnGEMRspPPFmtSend(ProcessProgram.OnReciveS7F24FormattedProcessProgramAck);
            //收到 HOST 的要求 Fmt PP 上傳
            mXGem.OnGEMReqPPFmt += new OnGEMReqPPFmt(ProcessProgram.OnReciveS7F25FormattedProcessProgramRequest);
            //收到 HOST 的回覆 Fmt PP 下傳
            mXGem.OnGEMRspPPFmt += new OnGEMRspPPFmt(ProcessProgram.OnReciveS7F26FormattedProcessProgramData);
            mXGem.OnGEMRspPPFmtVerification += new OnGEMRspPPFmtVerification(ProcessProgram.OnReciveS7F28PPVerifyAck);

            //收到 HOST 的TerminalMessage
            mXGem.OnGEMTerminalMessage += new OnGEMTerminalMessage(TerminalServices.OnReciveS10F3TerminalDisplaySingle);
            //收到 HOST 的TerminalMessage
            mXGem.OnGEMTerminalMultiMessage += new OnGEMTerminalMultiMessage(TerminalServices.OnReciveS10F5TerminalDisplayMultiBlock);
         
            
            //mXGem.OnGEMRspAllECInfo += new OnGEMRspAllECInfo(OnGEMRspAllECInfo);
            //mXGem.OnGEMReqPPSendEx += new OnGEMReqPPSendEx(m_XGem_OnGEMReqPPSendEx);

        }

        public class AddMessageArgs : EventArgs
        {
            public string Message = string.Empty;
        }

        public delegate void AddMessageCallBack(string _Message);
        public static AddMessageCallBack AddMessage;

        public static void Initialize(string sCfg)
        {
            long nReturn = 0;
            string Message = string.Empty;
            if ((nReturn = mXGem.Initialize(sCfg)) == 0)
            {
                Message = string.Format("[EQ ==> XGEM] XGem initialized successfully ({0})", nReturn);
            }
            else
            {
                Message = string.Format("[EQ ==> XGEM] Fail to initialize XGem ({0})", nReturn);
            }
            AddMessage(Message);
        }

        public static void Start()
        {
            long nReturn = 0;
            string Message = string.Empty;
            if ((nReturn = mXGem.Start()) == 0)
            {
                Message = string.Format("[EQ ==> XGEM] XGem started successfully ({0})", nReturn);
            }
            else
            {
                Message = string.Format("[EQ ==> XGEM] Fail to start XGem ({0})", nReturn);
            }

            AddMessage(Message);
        }

        public static void Stop()
        {
            long nReturn = 0;
            string Message = string.Empty;

            if ((nReturn = mXGem.Stop()) == 0)
            {
                Message = string.Format("[EQ ==> XGEM] XGem stopped successfully ({0})", nReturn);
            }
            else
            {
                Message = string.Format("[EQ ==> XGEM] Fail to stop XGem ({0})", nReturn);
            }

            AddMessage(Message);
        }

        public static void Closes()
        {
            long nReturn = 0;
            string Message = string.Empty;

            if ((nReturn = mXGem.Close()) == 0)
            {
                Message = string.Format("[EQ ==> XGEM] XGem closed successfully ({0})", nReturn);
            }
            else
            {
                Message = string.Format("[EQ ==> XGEM] Fail to close XGem ({0})", nReturn);
            }

            AddMessage(Message);
        }

        public static void OnGEMErrorEvent(string sErrorName, long nErrorCode)
        {
            string sLog = String.Format("[XGEM ==> EQ] OnGEMErrorEvent : ErrorName({0}) ErrorCode({1})", sErrorName, nErrorCode);
            AddMessage(sLog);
        }

        public static void OnSECSMessageReceived(long nObjectID, long nStream, long nFunction, long nSysbyte)
        {
            long nReturn = 0;
            string sValue = "";
            sValue = String.Format("[XGEM ==> EQ] OnSECSMessageReceived : ObjectID({0}), S{1},F{2}, Sysbyte({3})",
                            nObjectID, nStream, nFunction, nSysbyte);
            AddMessage(sValue);

            if ((nStream == 1) && (nFunction == 7))
            {
                byte[] pbValue = new byte[1];
                mXGem.GetBinaryItem(nObjectID, ref pbValue);
                AddMessage(string.Format("SFCD {0}", pbValue[0]));
                mXGem.CloseObject(nObjectID);
                Userdefinedmessage.SendS1F8(nSysbyte);

            }
            if ((nStream == 6) && (nFunction == 12))
            {
                byte[] pbValue = new byte[1] ;
                mXGem.GetBinaryItem(nObjectID, ref pbValue);
                mXGem.CloseObject(nObjectID);
                AddMessage(string.Format("ACKC6 {0}", pbValue[0]));
            }
            #region S101F101
            else if ((nStream == 101) && (nFunction == 101))
            {
                string sAscii = null;
                long nItems = 0;
                sbyte[] pnI1 = new sbyte[1];
                short[] pnI2 = new short[1];
                byte[] pnU1 = new byte[1];
                byte[] pnBinary = new byte[1];
                bool[] pnBool = new bool[1];
                int[] plI4 = new int[1];
                int[] plI8 = new int[1];
                ushort[] plU2 = new ushort[1];
                float[] prF4 = new float[1];
                uint[] prU4 = new uint[1];
                uint[] prU8 = new uint[1];
                double[] prF8 = new double[1];

                //  Get data of the received message.
                mXGem.GetListItem(nObjectID, ref nItems);
                AddMessage(string.Format("LIST {0}", nItems));
                mXGem.GetListItem(nObjectID, ref nItems);
                AddMessage(string.Format("   LIST {0}", nItems));
                // Read I1 value
                mXGem.GetInt1Item(nObjectID, ref pnI1);
                AddMessage(string.Format("       INT1 {0}", pnI1[0]));
                // Read I2 value
                mXGem.GetInt2Item(nObjectID, ref pnI2);
                AddMessage(string.Format("       INT2 {0}", pnI2[0]));
                // Read I4 value
                mXGem.GetInt4Item(nObjectID, ref plI4);
                AddMessage(string.Format("       INT4 {0}", plI4[0]));
                // Read I8 value
                mXGem.GetInt4Item(nObjectID, ref plI8);
                AddMessage(string.Format("       INT4 {0}", plI8[0]));
                // Read U1 value
                mXGem.GetUint1Item(nObjectID, ref pnU1);
                AddMessage(string.Format("       UINT1 {0}", pnU1[0]));
                // Read U2 value
                mXGem.GetUint2Item(nObjectID, ref plU2);
                AddMessage(string.Format("       UINT2 {0}", plU2[0]));
                // Read U4 value
                mXGem.GetUint4Item(nObjectID, ref prU4);
                AddMessage(string.Format("       UINT4 {0}", prU4[0]));
                // Read U8 value
                mXGem.GetUint4Item(nObjectID, ref prU8);
                AddMessage(string.Format("       UINT4 {0}", prU8[0]));
                // Read F4 value
                mXGem.GetFloat4Item(nObjectID, ref prF4);
                AddMessage(string.Format("       FLOAT4 {0}", prF4[0]));
                // Read F8 value
                mXGem.GetFloat8Item(nObjectID, ref prF8);
                AddMessage(string.Format("       FLOAT8 {0}", prF8[0]));
                // Read List Count
                mXGem.GetListItem(nObjectID, ref nItems);
                AddMessage(string.Format("   LIST {0}", nItems));
                // Read String value
                mXGem.GetStringItem(nObjectID, ref sAscii);
                AddMessage(string.Format("       ASCII {0}", sAscii));
                // Read Binary value
                mXGem.GetBinaryItem(nObjectID, ref pnBinary);
                AddMessage(string.Format("       BINARY {0}", pnBinary[0]));
                // Read Bool value
                mXGem.GetBoolItem(nObjectID, ref pnBool);
                AddMessage(string.Format("       BOOL {0}", pnBool[0]));
                mXGem.CloseObject(nObjectID);

                //  Send a reply message S101F102
                Userdefinedmessage.SendS101F102(nSysbyte);
            } 
            #endregion
            #region S101F103
            else if ((nStream == 101) && (nFunction == 103))
            {
                int MAX_ARRAY = 7;
                // Variable for array
                sbyte[] VALUE_I1_ARR = new sbyte[MAX_ARRAY];
                short[] VALUE_I2_ARR = new short[MAX_ARRAY];
                int[] VALUE_I4_ARR = new int[MAX_ARRAY];
                int[] VALUE_I8_ARR = new int[MAX_ARRAY];
                byte[] VALUE_U1_ARR = new byte[MAX_ARRAY];
                ushort[] VALUE_U2_ARR = new ushort[MAX_ARRAY];
                uint[] VALUE_U4_ARR = new uint[MAX_ARRAY];
                uint[] VALUE_U8_ARR = new uint[MAX_ARRAY];
                float[] VALUE_F4_ARR = new float[MAX_ARRAY];
                double[] VALUE_F8_ARR = new double[MAX_ARRAY];
                bool[] VALUE_BOOL_ARR = new bool[MAX_ARRAY];
                byte[] VALUE_BINARY_ARR = new byte[MAX_ARRAY];
                string VALUE_STRING = string.Empty;

                long nItems = 0;
                string szTemp;
                string szMsg;
                long lCnt = 0;


                mXGem.GetListItem(nObjectID, ref nItems);
                AddMessage(string.Format("LIST {0}", nItems));
                szMsg = "   BOOL ";
                mXGem.GetBoolItem(nObjectID, ref VALUE_BOOL_ARR);
                lCnt = VALUE_BOOL_ARR == null ? 0 : VALUE_BOOL_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0} ", VALUE_BOOL_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   BINARY ";
                mXGem.GetBinaryItem(nObjectID, ref VALUE_BINARY_ARR);
                lCnt = VALUE_BINARY_ARR == null ? 0 : VALUE_BINARY_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0} ", VALUE_BINARY_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   UINT1 ";
                mXGem.GetUint1Item(nObjectID, ref VALUE_U1_ARR);
                lCnt = VALUE_U1_ARR == null ? 0 : VALUE_U1_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0} ", VALUE_U1_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   UINT2 ";
                mXGem.GetUint2Item(nObjectID, ref VALUE_U2_ARR);
                lCnt = VALUE_U2_ARR == null ? 0 : VALUE_U2_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0} ", VALUE_U2_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   UINT4 ";
                mXGem.GetUint4Item(nObjectID, ref VALUE_U4_ARR);
                lCnt = VALUE_U4_ARR == null ? 0 : VALUE_U4_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0} ", VALUE_U4_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   UINT4 ";
                mXGem.GetUint4Item(nObjectID, ref VALUE_U8_ARR);
                lCnt = VALUE_U8_ARR == null ? 0 : VALUE_U8_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0} ", VALUE_U8_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   INT1 ";
                mXGem.GetInt1Item(nObjectID, ref VALUE_I1_ARR);
                lCnt = VALUE_I1_ARR == null ? 0 : VALUE_I1_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0} ", VALUE_I1_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   INT2 ";
                mXGem.GetInt2Item(nObjectID, ref VALUE_I2_ARR);
                lCnt = VALUE_I2_ARR == null ? 0 : VALUE_I2_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0} ", VALUE_I2_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   INT4 ";
                mXGem.GetInt4Item(nObjectID, ref VALUE_I4_ARR);
                lCnt = VALUE_I4_ARR == null ? 0 : VALUE_I4_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0} ", VALUE_I4_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   INT4 ";
                mXGem.GetInt4Item(nObjectID, ref VALUE_I8_ARR);
                lCnt = VALUE_I8_ARR == null ? 0 : VALUE_I8_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0} ", VALUE_I8_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   FLOAT4 ";
                mXGem.GetFloat4Item(nObjectID, ref VALUE_F4_ARR);
                lCnt = VALUE_F4_ARR == null ? 0 : VALUE_F4_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0:f6} ", VALUE_F4_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);
                szMsg = "   FLOAT8 ";
                mXGem.GetFloat8Item(nObjectID, ref VALUE_F8_ARR);
                lCnt = VALUE_F8_ARR == null ? 0 : VALUE_F8_ARR.Length;
                for (int i = 0; i < lCnt; i++)
                {
                    szTemp = String.Format("{0:f6} ", VALUE_F8_ARR[i]);
                    szMsg += szTemp;
                }
                AddMessage(szMsg);

                szMsg = "   ASCII ";
                mXGem.GetStringItem(nObjectID, ref VALUE_STRING);
                szTemp = VALUE_STRING;
                szMsg += szTemp;
                AddMessage(szMsg);

                mXGem.CloseObject(nObjectID);

                //  Send a reply message S101F104
                Userdefinedmessage.SendS101F104(nSysbyte);
            } 
            #endregion
            else if ((nStream == 101) && (nFunction == 102))
            {
                mXGem.CloseObject(nObjectID);
            }
            else if ((nStream == 101) && (nFunction == 104))
            {
                // Get value
                // Read U1 value
                byte[] pnU1 = new byte[1];
                mXGem.GetUint1Item(nObjectID, ref pnU1);
                AddMessage(string.Format("UINT1 {0}", pnU1[0]));
                mXGem.CloseObject(nObjectID);
            }
            else
            {
                AddMessage(string.Format("Undefined message received (S{0}F{1})", nStream, nFunction));
                mXGem.CloseObject(nObjectID);
            }
        }

        public static void OnGEMSecondaryMsgReceived(long nS, long nF, long nSysbyte, string sParam1, string sParam2, string sParam3)
        {
            string sLog = String.Format("[XGEM ==> EQ] OnGEMSecondaryMsgReceived");
            AddMessage(sLog);

            sLog = String.Format("               stream:{0}, function:{1}, sysbyte:{2}, Param1:{3}, Param2:{4}, Param3:{5}", nS, nF, nSysbyte, sParam1, sParam2, sParam3);
            AddMessage(sLog);


        }

        public static void OnXGEMStateEvent(long nState)
        {
            //throw new Exception("The method or operation is not implemented.");
            string szState = null;

            if (nState == -1) { szState = "Unknown"; }
            else if (nState == 0) { szState = "Init"; }
            else if (nState == 1) { szState = "Idle"; }
            else if (nState == 2) { szState = "Setup"; }
            else if (nState == 3) { szState = "Ready"; }
            else if (nState == 4) { szState = "Execute"; }
            else { szState = "Unknown"; }

            string sLog = String.Format("[XGEM ==> EQ] OnXGEMStateEvent:{0}", szState);
            AddMessage(sLog);

            if (nState == 4)
            {
                EstablishCommunation.GEMSetEstablish(true);
                sLog = String.Format("[EQ ==> XGEM] GEMSetEstablish");
                AddMessage(sLog);

            }
        }

        public class EstablishCommunation
        {
            public class CommuncationStateArgs : EventArgs
            {
                public string StateString = string.Empty;
            }

            public static event EventHandler<CommuncationStateArgs> OnCommuncationStateChangeEvent;

            public static void OnGEMCommStateChanged(long nState)
            {
                string szState = null;

                if (nState == 1) { szState = "Comm Disabled"; }
                else if (nState == 2) { szState = "WaitCRFromHost"; }
                else if (nState == 3) { szState = "WaitDelay"; }
                else if (nState == 4) { szState = "WaitCRA"; }
                else if (nState == 5) { szState = "Communicating"; }
                else { szState = "Comm Disabled"; }

                CommuncationStateArgs Args = new CommuncationStateArgs();
                Args.StateString = szState;
                if (OnCommuncationStateChangeEvent != null)
                {
                    OnCommuncationStateChangeEvent(null, Args);
                }

                string Message = String.Format("[XGEM ==> EQ] OnGEMCommStateChanged:{0}", szState);
                AddMessage(Message);

                if (nState == 5)
                {
                    ControlState.OnControlStateChanged(ControlState.GetControlStateValue());
                }
            }

            public static void GEMSetEstablish(bool Enable)
            {

                long nReturn = 0;

                //Argument : bState value(0: disable, 1: enable)
                long bState = Enable ? 1 : 0;
                string Message = string.Empty;

                nReturn = mXGem.GEMSetEstablish(bState);
                if (nReturn == 0)
                {
                    Message = string.Format("[EQ ==> XGEM] GEMSetEstablish successfully ({0})", nReturn);
                }
                else
                {
                    Message = string.Format("[EQ ==> XGEM] Fail to GEMSetEstablish ({0})", nReturn);
                }

                AddMessage(Message);
            }
        }

        public class ControlState
        {

            public class ControlStateArgs : EventArgs
            {
                public string StateString = string.Empty;
            }

            public static event EventHandler<ControlStateArgs> OnControlStateChangeEvent;

            public static void OnControlStateChanged(long nState)
            {
                //throw new Exception("The method or operation is not implemented.");
                string szState = null;

                if (nState == 1) { szState = "OffLine"; }
                else if (nState == 2) { szState = "Attempt OnLine"; }
                else if (nState == 3) { szState = "Host OffLine"; }
                else if (nState == 4) { szState = "Online-Local"; }
                else if (nState == 5) { szState = "Online-Remote"; }
                else { szState = "OffLine"; }

                ControlStateArgs Args = new ControlStateArgs();
                Args.StateString = szState;
                if (OnControlStateChangeEvent != null)
                {
                    OnControlStateChangeEvent(null, Args);
                }

                string sLog = String.Format("[XGEM ==> EQ] OnGEMControlStateChanged:{0}", szState);
                AddMessage(sLog);
            }

            public static void OnReciveS1F15HostRequestOffline(long nSystemByte, long nFromState, long nToState)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqOffline");
                AddMessage(sLog);

                sLog = String.Format("               nSystemByte:{0}, nFromState:{1}, nToState:{2}", nSystemByte, nFromState, nToState);
                AddMessage(sLog);

                SendS1F16HostOfflineAck(nSystemByte, 0);
            }

            public static void SendS1F16HostOfflineAck(long nSystemByte, long OFLACK)
            {
                mXGem.GEMRsqOffline(nSystemByte, OFLACK);
                string sLog = String.Format("[EQ ==> XGEM] GEMRsqOffline => nSystemByte:{0}, nAck:{1}", nSystemByte, 0);
                AddMessage(sLog);
            }

            public static void OnReciveS1F17HostRequestOnline(long nSystemByte, long nFromState, long nToState)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqOnline");
                AddMessage(sLog);

                sLog = String.Format("               nSystemByte:{0}, nFromState:{1}, nToState:{2}", nSystemByte, nFromState, nToState);
                AddMessage(sLog);

                SendS1F18HostOnlineAck(nSystemByte, 0);
            }

            public static void SendS1F18HostOnlineAck(long nSystemByte, long ONLACK)
            {
                mXGem.GEMRspOnline(nSystemByte, ONLACK);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspOnline => nSystemByte:{0}, nAck:{1}", nSystemByte, 0);
                AddMessage(sLog);
            }

            public static void ReqOffline()
            {

                long nReturn = 0;
                //Argument : None
                nReturn = mXGem.GEMReqOffline();
                if (nReturn == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] GEMReqOffline successfully ({0})", nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMReqOffline ({0})", nReturn));
                }        
            }

            public static void ReqOnlineLocal()
            {

                long nReturn = 0;
                nReturn = mXGem.GEMReqLocal();
                if (nReturn == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] GEMReqLocal successfully ({0})", nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMReqLocal ({0})", nReturn));
                }
            }

            public static void ReqOnlineRemote()
            {

                long nReturn = 0;
                nReturn = mXGem.GEMReqRemote();
                if (nReturn == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] GEMReqRemote successfully ({0})", nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMReqRemote ({0})", nReturn));
                }
            }

            public static void ReqHostOffline()
            {
                long nReturn = 0;
                nReturn = mXGem.GEMReqHostOffline();
                if (nReturn == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] GEMReqHostOffline successfully ({0})", nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMReqHostOffline ({0})", nReturn));
                }
            }

            public static string GetControlState()
            { 
                string _Value = string.Empty;
                VariableData.GetVariable("ControlState", ref _Value);
                long nState = Convert.ToInt64(_Value);
                string szState = string.Empty; 

                if (nState == 1) { szState = "OffLine"; }
                else if (nState == 2) { szState = "Attempt OnLine"; }
                else if (nState == 3) { szState = "Host OffLine"; }
                else if (nState == 4) { szState = "Online-Local"; }
                else if (nState == 5) { szState = "Online-Remote"; }
                else { szState = "OffLine"; }

                return szState;
            }

            public static long GetControlStateValue()
            {
                string _Value = string.Empty;
                VariableData.GetVariable("ControlState", ref _Value);
                long nState = Convert.ToInt64(_Value);

                return nState;
            }
        }

        public class RemoteControl
        {

            public class S2F41Args : EventArgs
            {
                public long SystemByte = 0x00;
                public string RCMD = string.Empty;
                public Dictionary<string, string> CPVAL = new Dictionary<string, string>();
                //public long HCACK = 0x00;
                //public Dictionary<string, long> CPACK = new Dictionary<string, long>();
            }

            public static event EventHandler<S2F41Args> OnReciveS2F41ArgsEvent;

            //S2F41	Host Command Send

            public static void OnReciveS2F41HostCommandSend(long nSystemByte, string sRcmd, long nCount, string[] psNames, string[] psVals)
            {
                //throw new Exception("The method or operation is not implemented.");
                string Message = String.Format("[XGEM ==> EQ] OnGEMReqRemoteCommand : Remote Command({0}), ", sRcmd);
                AddMessage(Message);

                for (int i = 0; i < nCount; i++)
                {
                    Message = String.Format("               Name: {0}, Value: {1}", psNames[i], psVals[i]);
                    AddMessage(Message);
                }
                

                if (OnReciveS2F41ArgsEvent != null)
                {
                    S2F41Args Args = new S2F41Args();
                    Args.SystemByte = nSystemByte;
                    Args.RCMD = sRcmd;
                    for (int i = 0x00; i < nCount; i++)
                    {
                        Args.CPVAL.Add(psNames[i], psVals[i]);
                    }

                    OnReciveS2F41ArgsEvent(null, Args);
                    //SendS2F42HostCommandAck(nMsgId, sRcmd, 0x00, Args.CPACK);
                }
                else
                {

                    Dictionary<string, long> CpAck = new Dictionary<string, long>();
                    CpAck.Clear();
                    SendS2F42HostCommandAck(nSystemByte, sRcmd, 0, CpAck);
                }
            }

            public static void SendS2F42HostCommandAck(long nSystemByte, string sRcmd, long HCACK, Dictionary<string, long> CPACK)
            {
                //HCACK Acknowledge Code, 1 byte
                //0: Acknowledge, command has been performed
                //1: Command does not exist
                //2: Cannot perform now
                //3: At least one parameter is invalid
                //4: Acknowledge, command will be performed with completion signaled later by an event
                //5: Rejected, already in desired condition
                //6: No such object exists

                string[] psNames = new string[CPACK.Count];
                long[] nResult = new long[CPACK.Count];

                for (int i = 0x00; i < CPACK.Count; i++)
                {
                    psNames[i] = CPACK.ElementAt(i).Key;
                    nResult[i] = CPACK.ElementAt(i).Value;
                }

                mXGem.GEMRspRemoteCommand(nSystemByte, sRcmd, HCACK, CPACK.Count, psNames, nResult);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspRemoteCommand");
                AddMessage(sLog);
            }
        
        }

        public class EventNotification
        {
            public static void SendS6F11EventReportSend(long nEventID)
            {
                long nReturn = 0;
                nReturn = mXGem.GEMSetEvent(nEventID);
                string sLog = String.Format("[EQ ==> XGEM] GEMSetEvent => ID:{0} ({1})", nEventID, nReturn);
                AddMessage(sLog);
            }
            
        }

        public class AlarmManagement
        {
            public static void SendS5F1AlarmReportSend(long nAlarmID, bool bState)
            {
                long nReturn = 0;
                long nState = bState ? 0x01 : 0x00;
                nReturn = mXGem.GEMSetAlarm(nAlarmID, nState);
                string sLog = String.Format("[EQ ==> XGEM] GEMSetAlarm => ID:{0}, State:{1} ({2})", nAlarmID, 0, nReturn);
                AddMessage(sLog);
            }
        }

        public class TerminalServices
        {
            public static void SendS10F1TerminalRequest(long nTid, string sMsg)
            {
                long nReturn = mXGem.GEMSetTerminalMessage(nTid, sMsg);
                string sLog = String.Format("[EQ ==> XGEM] GEMSetTerminalMessage => Tid:{0}, Msg:{1} ({2})", nTid, sMsg, nReturn);
                AddMessage(sLog);
            }

            public class TerminalDisplayArgs : EventArgs
            {
                public long TID = 0x00;
                public List<string> Messages = new List<string>();
            }

            public static event EventHandler<TerminalDisplayArgs> OnReciveHostReqTerminalDisplayEvent;

            public static void OnReciveS10F3TerminalDisplaySingle(long nTid, string sMsg)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMTerminalMessage : Tid({0}), Msg({1})", nTid, sMsg);
                AddMessage(sLog);

                if (OnReciveHostReqTerminalDisplayEvent != null)
                {
                    TerminalDisplayArgs Args = new TerminalDisplayArgs();

                    Args.TID = nTid;
                    Args.Messages.Add(sMsg);
                    OnReciveHostReqTerminalDisplayEvent(null, Args);
                }
            }

            public static void OnReciveS10F5TerminalDisplayMultiBlock(long nTid, long nCount, string[] psMsg)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMTerminalMultiMessage : Tid({0}), ", nTid);
                AddMessage(sLog);

                for (int i = 0; i < nCount; i++)
                {
                    sLog = String.Format("               B: {0}", psMsg[i]);
                    AddMessage(sLog);
                }

                if (OnReciveHostReqTerminalDisplayEvent != null)
                {
                    TerminalDisplayArgs Args = new TerminalDisplayArgs();
                    Args.TID = nTid;

                    for (int i = 0x00; i < nCount; i++)
                    {
                        Args.Messages.Add(psMsg[i]);
                    }
                    OnReciveHostReqTerminalDisplayEvent(null, Args);
                }
            }
        }

        public class EquipmentConstants
        {
            public static void SetEcvChangde(Dictionary<long,string>_ECV)
            {
                //修改EC 並發事件
                long nReturn = 0;
                long nCount = _ECV.Count;
                long[] naEcid = new long[_ECV.Count];
                string[] saVals = new string[_ECV.Count];

                for (int i = 0x00; i < _ECV.Count; i++)
                {
                    naEcid[i] = _ECV.ElementAt(i).Key;
                    saVals[i] = _ECV.ElementAt(i).Value;
                }
                nReturn = mXGem.GEMSetECVChanged(nCount, naEcid, saVals);
                string sLog = String.Format("[EQ ==> XGEM] GEMSetECVChanged => Ecid:{0}, Val:{1} ({2})", naEcid[0], saVals[0], nReturn);
                AddMessage(sLog);
                
            }

            public static void GetEcv(long Vid, ref string _Value)
            {
     
                long[] naId = new long[1];
                string[] saVal = new string[1];
                naId[0] = Vid;
                long nReturn = 0;
                nReturn = mXGem.GEMGetVariable(1, ref naId, ref saVal);
                _Value = saVal[0];
                string sLog = String.Format("[EQ ==> XGEM] GEMGetVariable => Id:{0}, Val:{1} ({2})", naId[0], saVal[0], nReturn);
                AddMessage(sLog);

            }

            public class S2F15Args : EventArgs
            {
                public long SystemByte = 0x00;
                public Dictionary<long, string> Ecv = new Dictionary<long, string>();
            }

            public static event EventHandler<S2F15Args> OnReciveS2F15Event;

            public static void OnReciveS2F15NewEcvSend(long nSystemByte, long nCount, long[] pnEcids, string[] psVals)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqChangeECV");
                AddMessage(sLog);

                for (int i = 0; i < nCount; i++)
                {
                    sLog = String.Format("     Ecid:{0}, Value:{1}", pnEcids[i], psVals[i]);
                    AddMessage(sLog);
                }

                if (OnReciveS2F15Event != null)
                {
                    S2F15Args Args = new S2F15Args();
                    Args.SystemByte = nSystemByte;
                    Args.Ecv.Clear();
                    for (int i = 0x00; i < nCount; i++)
                    {
                        Args.Ecv.Add(pnEcids[i], psVals[i]);
                    }
                    OnReciveS2F15Event(null, Args);
                }
                else
                {
                    SendS2F16NewEcvAck(nSystemByte, 2);
                }
            }

            public static void SendS2F16NewEcvAck(long nSystemByte, long EAC)
            {
                // Equipment acknowledge code, 1 byte
                //0: Acknowledge
                //1: Denied; at least one constant does not exist
                //2: Denied; busy
                //3: Denied; at least one constant out of range
                //> 3: Other equipment-specific error

                mXGem.GEMRspChangeECV(nSystemByte, 0);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspChangeECV");
                AddMessage(sLog);
            }

            public static void OnGEMECVChanged(long nCount, long[] pnEcids, string[] psVals)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMECVChanged");
                AddMessage(sLog);

                for (int i = 0; i < nCount; i++)
                {
                    sLog = String.Format("               Ecid:{0}, Value:{1}", pnEcids[i], psVals[i]);
                    AddMessage(sLog);
                }
            }
        }

        public class VariableData
        {
            public static void SetVariable(Dictionary<long, string> _Value)
            {
                long nReturn = 0;
                long nCount = _Value.Count;
                long[] naVidName = new long[_Value.Count];
                string[] saVidValue = new string[_Value.Count];

                for (int i = 0x00; i < _Value.Count; i++)
                {
                    naVidName[i] = _Value.ElementAt(i).Key;
                    saVidValue[i] = _Value.ElementAt(i).Value;
                }

                nReturn = mXGem.GEMSetVariable(nCount, naVidName, saVidValue);
                string sLog = String.Format("[EQ ==> XGEM] GEMSetVariable => VidName:{0}, VidValue:{1} ({2})", naVidName[0], saVidValue[0], nReturn);
                AddMessage(sLog);
            }

            public static void SetVariable(long _Vid, string _Value)
            {
                long nReturn = 0;
                long nCount = 0x01;
                long[] naVidName = new long[1];
                string[] saVidValue = new string[1];

                naVidName[0] = _Vid;
                saVidValue[0] = _Value;
                nReturn = mXGem.GEMSetVariable(nCount, naVidName, saVidValue);
                string sLog = String.Format("[EQ ==> XGEM] GEMSetVariable => VidName:{0}, VidValue:{1} ({2})", naVidName[0], saVidValue[0], nReturn);
                AddMessage(sLog);
            }

            public static void SetVariable(Dictionary<string, string> _Value)
            {
                long nReturn = 0;
                long nCount = _Value.Count;
                string[] naVidName = new string[_Value.Count];
                string[] saVidValue = new string[_Value.Count];

                for (int i = 0x00; i < _Value.Count; i++)
                {
                    naVidName[i] = _Value.ElementAt(i).Key;
                    saVidValue[i] = _Value.ElementAt(i).Value;
                }

                nReturn = mXGem.GEMSetVarName(nCount, naVidName, saVidValue);
                string sLog = String.Format("[EQ ==> XGEM] GEMSetVarName => VidName:{0}, VidValue:{1} ({2})", naVidName[0], saVidValue[0], nReturn);
                AddMessage(sLog);
            }

            public static void SetVariable(string _VidName, string _Value)
            {
                long nReturn = 0;
                long nCount = 0x01;
                string[] naVidName = new string[1];
                string[] saVidValue = new string[1];

                naVidName[0] = _VidName;
                saVidValue[0] = _Value;
                nReturn = mXGem.GEMSetVarName(nCount, naVidName, saVidValue);
                string sLog = String.Format("[EQ ==> XGEM] GEMSetVarName => VidName:{0}, VidValue:{1} ({2})", naVidName[0], saVidValue[0], nReturn);
                AddMessage(sLog);
            }

            public static void GetVariable(long _Vid, ref string _Value)
            {
                long[] naId = new long[1];
                string[] saVal = new string[1];
                naId[0] = _Vid;
                long nReturn = 0;
                nReturn = mXGem.GEMGetVariable(1, ref naId, ref saVal);
                _Value = saVal[0];
                string sLog = String.Format("[EQ ==> XGEM] GEMGetVariable => Id:{0}, Val:{1} ({2})", naId[0], saVal[0], nReturn);
                AddMessage(sLog);
            }

            public static void GetVariable(Dictionary<long, string> _Value)
            {
                long nCount = _Value.Count;
                long[] naId = new long[_Value.Count];
                string[] saVal = new string[_Value.Count];
                for (int i = 0x00; i < _Value.Count; i++)
                {
                    naId[i] = _Value.ElementAt(i).Key;
                }
                long nReturn = 0;
                nReturn = mXGem.GEMGetVariable(nCount, ref naId, ref saVal);
                _Value.Clear();
                for (int i = 0x00; i < nCount; i++)
                {
                    _Value.Add(naId[i], saVal[i]);
                }

                string sLog = String.Format("[EQ ==> XGEM] GEMGetVariable => Id:{0}, Val:{1} ({2})", naId[0], saVal[0], nReturn);
                AddMessage(sLog);
            }

            public static void GetVariable(string _VidName, ref string _Value)
            {
                long nCount = 1;
                string[] naId = new string[1];
                string[] saVal = new string[1];
                naId[0] = _VidName;
                long nReturn = 0;
                nReturn = mXGem.GEMGetVarName(nCount, ref naId, ref saVal);
                _Value = saVal[0];
                string sLog = String.Format("[EQ ==> XGEM] GEMGetVariable => Id:{0}, Val:{1} ({2})", naId[0], saVal[0], nReturn);
                AddMessage(sLog);
            }

            public static void GetVariable(Dictionary<string, string> _Value)
            {
                long nCount = _Value.Count;
                string[] naId = new string[_Value.Count];
                string[] saVal = new string[_Value.Count];
                for (int i = 0x00; i < _Value.Count; i++)
                {
                    naId[i] = _Value.ElementAt(i).Key;
                }
                long nReturn = 0;
                nReturn = mXGem.GEMGetVarName(nCount, ref naId, ref saVal);
                _Value.Clear();
                for (int i = 0x00; i < nCount; i++)
                {
                    _Value.Add(naId[i], saVal[i]);
                }

                string sLog = String.Format("[EQ ==> XGEM] GEMGetVariable => Id:{0}, Val:{1} ({2})", naId[0], saVal[0], nReturn);
                AddMessage(sLog);
            }

            public static void SetVId1010(List<uint> _Value)
            {
                long nReturn = 0;
                long nObjectID = 0x00;
                uint[] naValue = _Value.ToArray();

                #region makeObject
                if ((nReturn = mXGem.MakeObject(ref nObjectID)) == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] XGem MakeObject({0}) successfully ({1})", nObjectID, nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to MakeObject({0}) ({1})", nObjectID, nReturn));
                }
                #endregion
                #region SetU4
                if ((nReturn = mXGem.SetUint4Item(nObjectID, naValue)) == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] XGem SetU4({0}) successfully ({1})", nObjectID, nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to SetU4({0}) ({1})", nObjectID, nReturn));
                }
                #endregion

                #region Update variable
                // 1. Update variable  
                long Vid = 1010;
                if ((nReturn = mXGem.GEMSetVariables(nObjectID, Vid)) == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] XGem GEMSetVariables({0},{1}) successfully ({2})", nObjectID, Vid, nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMSetVariables({0},{1}) ({2})", nObjectID, Vid, nReturn));
                }
                #endregion
            }

            public static void SetVId1011(string[] saLotId, string[] saSubstId)
            {
                long nReturn = 0;
                long nObjectID = 0x00;

                #region makeObject
                if ((nReturn = mXGem.MakeObject(ref nObjectID)) == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] XGem MakeObject({0}) successfully ({1})", nObjectID, nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to MakeObject({0}) ({1})", nObjectID, nReturn));
                }
                #endregion
                #region SetList
                if ((nReturn = mXGem.SetListItem(nObjectID, saLotId.Length)) == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] XGem SetList({0},25) successfully ({1})", nObjectID, nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to SetList({0},25) ({1})", nObjectID, nReturn));
                }
                #endregion
                for (int i = 0; i < saLotId.Length; i++)
                {
                    if ((nReturn = mXGem.SetListItem(nObjectID, 2)) == 0)
                    {
                        AddMessage(string.Format("[EQ ==> XGEM]      XGem SetList({0},2) successfully ({1})", nObjectID, nReturn));
                    }
                    else
                    {
                        AddMessage(string.Format("[EQ ==> XGEM]      Fail to SetList({0},2) ({1})", nObjectID, nReturn));
                    }

                    if ((nReturn = mXGem.SetStringItem(nObjectID, saSubstId[i])) == 0)
                    {
                        AddMessage(string.Format("[EQ ==> XGEM]          XGem SetAscii({0},{1}) successfully ({2})", nObjectID, saSubstId[i], nReturn));
                    }
                    else
                    {
                        AddMessage(string.Format("[EQ ==> XGEM]          Fail to SetAscii({0},{1}) ({2})", nObjectID, saSubstId[i], nReturn));
                    }
                    if ((nReturn = mXGem.SetStringItem(nObjectID, saLotId[i])) == 0)
                    {
                        AddMessage(string.Format("[EQ ==> XGEM]          XGem SetAscii({0},{1}) successfully ({2})", nObjectID, saLotId[i], nReturn));
                    }
                    else
                    {
                        AddMessage(string.Format("[EQ ==> XGEM]          Fail to SetAscii({0},{1}) ({2})", nObjectID, saLotId[i], nReturn));
                    }
                }

                #region Update variable
                // 1. Update variable  
                long Vid = 1011;
                if ((nReturn = mXGem.GEMSetVariables(nObjectID, Vid)) == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] XGem GEMSetVariables({0},{1}) successfully ({2})", nObjectID, Vid, nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMSetVariables({0},{1}) ({2})", nObjectID, Vid, nReturn));
                }
                #endregion
            }

            public static void SetVId1012(string sSlotMap, byte[] naSlotId)
            {
                long nReturn = 0;
                long nObjectID = 0x00;
                long Vid = 1012;

                #region makeObject
                if ((nReturn = mXGem.MakeObject(ref nObjectID)) == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] XGem MakeObject({0}) successfully ({1})", nObjectID, nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to MakeObject({0}) ({1})", nObjectID, nReturn));
                }
                #endregion
                #region SetList
                if ((nReturn = mXGem.SetListItem(nObjectID, 2)) == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] XGem SetList({0},2) successfully ({1})", nObjectID, nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to SetList({0},2) ({1})", nObjectID, nReturn));
                }
                #endregion
                    #region SetAscii
                    if ((nReturn = mXGem.SetStringItem(nObjectID, sSlotMap)) == 0)
                    {
                        AddMessage(string.Format("[EQ ==> XGEM]      XGem SetAscii({0},{1}) successfully ({2})", nObjectID, sSlotMap, nReturn));
                    }
                    else
                    {
                        AddMessage(string.Format("[EQ ==> XGEM]      Fail to SetAscii({0},{1}) ({2})", nObjectID, sSlotMap, nReturn));
                    }
                    #endregion
                    #region SetList
                    if ((nReturn = mXGem.SetListItem(nObjectID, 25)) == 0)
                    {
                        AddMessage(string.Format("[EQ ==> XGEM]      XGem SetList({0},25) successfully ({1})", nObjectID, nReturn));
                    }
                    else
                    {
                        AddMessage(string.Format("[EQ ==> XGEM]      Fail to SetList({0},25) ({1})", nObjectID, nReturn));
                    }
                    #endregion
                        #region SetU1
                        for (int i = 0; i < 25; i++)
                        {
                            if ((nReturn = mXGem.SetUint1Item(nObjectID, new byte[] { naSlotId[i] })) == 0)
                            {
                                AddMessage(string.Format("[EQ ==> XGEM]          XGem SetU1({0},{1}) successfully ({2})", nObjectID, naSlotId[i], nReturn));
                            }
                            else
                            {
                                AddMessage(string.Format("[EQ ==> XGEM]          Fail to SetU1({0},{1}) ({2})", nObjectID, naSlotId[i], nReturn));
                            }
                        }
                        #endregion

                #region Update variable
                // 1. Update variable  
                if ((nReturn = mXGem.GEMSetVariables(nObjectID, Vid)) == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] XGem GEMSetVariables({0},{1}) successfully ({2})", nObjectID, Vid, nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMSetVariables({0},{1}) ({2})", nObjectID, Vid, nReturn));
                }
                #endregion
            }
        }

        public class Clock
        {
            
            #region EQP -> HOST
            public class S2F18Args : EventArgs
            {
                public long SystemByte = 0x00;
                public string SystemTime = string.Empty;
            }
            public static void SendS2F17RDateTimeRequest()
            {
                long nReturn = 0;
                nReturn = mXGem.GEMReqGetDateTime();
                string sLog = String.Format("[EQ ==> XGEM] GEMReqGetDateTime ({0})", nReturn);
                AddMessage(sLog);
            }
            public static event EventHandler<S2F18Args> OnReciveS2F18Event;
            public static void OnReciveS2F18DateTimeData(string sSystemTime)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMRspGetDateTime : systemtime({0})", sSystemTime);
                AddMessage(sLog);

                if (OnReciveS2F18Event != null)
                {
                    S2F18Args Args = new S2F18Args();
                    Args.SystemTime = sSystemTime;
                    OnReciveS2F18Event(null, Args);
                }
            } 
            #endregion

            #region HOST -> EQP
            public class S2F17Args : EventArgs
            {
                public long nMsgId = 0x00;
            }
            public static event EventHandler<S2F17Args> OnReciveS2F17Event;

            public static void OnReciveS2F17DateTimeRequest(long nMsgId)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqGetDateTime");
                AddMessage(sLog);

                if (OnReciveS2F17Event != null)
                {
                    S2F17Args Args = new S2F17Args();
                    Args.nMsgId = nMsgId;
                    OnReciveS2F17Event(null, Args);
                    
                }
                else
                {
                    string sSystemTime = DateTime.Now.ToString("yyyyMMddHHmmss00");
                    SendS2F18DateTimeData(nMsgId, sSystemTime);
                }
            }

            public static void SendS2F18DateTimeData(long nMsgId, string sSystemTime)
            {
                long nReturn = 0;
                nReturn = mXGem.GEMRspGetDateTime(nMsgId, sSystemTime);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspGetDateTime ({0})", nReturn);
                AddMessage(sLog);
            }

            public class S2F31Args : EventArgs
            {
                public long nMsgId = 0x00;
                public string SystemTime = string.Empty;
            }
            public static event EventHandler<S2F31Args> OnReciveS2F31Event;

            public static void OnReciveS2F31DateTimeSetRequest(long nMsgId, string sSystemTime)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqDateTime : systemtime({0})", sSystemTime);
                AddMessage(sLog);

                if (OnReciveS2F31Event != null)
                {
                    S2F31Args Args = new S2F31Args();
                    Args.nMsgId = nMsgId;
                    Args.SystemTime = sSystemTime;
                    OnReciveS2F31Event(null, Args);
                }
                else
                {
                    SendS2F32DateTimeSetAck(nMsgId, 0);
                }
            }

            public static void SendS2F32DateTimeSetAck(long nMsgId, long TIACK)
            {
                //Time Acknowledge Code, 1 byte
                //0 = Accepted
                //1 = String is small.
                //2 = out of range

                long nReturn = 0;
                nReturn = mXGem.GEMRspDateTime(nMsgId, TIACK);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspDateTime");
                AddMessage(sLog);
            } 
            #endregion
        }

        public class ProcessProgram
        {

            public static void SetPPChanged(long nMode, string sPpid, byte[] psBody)
            {
                // Description: Unformatted Process Program이 생성, 수정, 삭제되었을 경우 사용함.
                long nReturn = 0;
                long nSize = 0;

                nSize = psBody.Length;

                //nMode : 1(Created), 2(Edited), 3(Deleted)
                nReturn = mXGem.GEMSetPPChanged(nMode, sPpid, nSize, psBody);
                if (nReturn == 0)
                {
                    AddMessage("[EQ ==> XGEM] GEMSetPPChanged successfully");
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMSetPPChanged ({0})", nReturn));
                } 
            }
            public static void SetPPChanged(long nMode, string sPpid, string sMdln, string sSoftRev, Dictionary<string, List<string>> Body)
            {
                long nReturn = 0;
                long nCount = Body.Count;
                string[] saCCodes = new string[Body.Count];
                long[] naPCount = new long[Body.Count];
                List<string> Tmp = new List<string>();
                for (int i = 0x00; i < Body.Count; i++)
                {
                    saCCodes[i] = Body.ElementAt(i).Key;
                    naPCount[i] = Body.ElementAt(i).Value.Count;

                    for (int j = 0x00; j < naPCount[i]; j++)
                    {
                        string str = Body.ElementAt(i).Value[j];
                        Tmp.Add(str);
                    }
                }
                string[] saPNames = Tmp.ToArray();


                //nMode : 1(Created), 2(Edited), 3(Deleted)
                nReturn = mXGem.GEMSetPPFmtChanged(nMode, sPpid, sMdln, sSoftRev, nCount, saCCodes, naPCount, saPNames);
                if (nReturn == 0)
                {
                    AddMessage("[EQ ==> XGEM] GEMSetPPChanged successfully");
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMSetPPChanged ({0})", nReturn));
                }
            }

            #region EQP -> Host
            public static void SendS7F1ProcessProgramLoadInquire(string sPpid, long nLength)
            {
                long nReturn = 0;

                nReturn = mXGem.GEMReqPPLoadInquire(sPpid, nLength);
                if (nReturn == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] GEMReqPPLoadInquire successfully"));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMReqPPLoadInquire ({0})", nReturn));
                } 
            }
            public class S7F2Args : EventArgs
            {
                public long PPGNT = 0x00;
            }
            public static event EventHandler<S7F2Args> OnReciveS7F2Event;
            public static void OnReciveS7F2ProcessProgramLoadGrant(string sPpid, long PPGNT)
            {
                //PPGNT
                //0 - Ok
                //1 - already have
                //2 - no space
                //3 - invalid PPID
                //4 - busy, try later
                //5 - will not accept
                //6 - other error
                //throw new Exception("The method or operation is not implemented.");
                string sLog = String.Format("[XGEM ==> EQ] OnGEMRspPPLoadInquire : Ppid({0}), Result({1})", sPpid, PPGNT);
                AddMessage(sLog);

                S7F2Args args = new S7F2Args();
                args.PPGNT = PPGNT;
                if (OnReciveS7F2Event != null)
                {
                    OnReciveS7F2Event(null, args);
                }
            }
            
            public static void SendS7F3ProcessProgramSend(string sPpid, byte[] psBody)
            {
                long nReturn = 0;

                nReturn = mXGem.GEMReqPPSend(sPpid, psBody);
                if (nReturn == 0)
                {
                    AddMessage("[EQ ==> XGEM] GEMReqPPSend successfully");
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMReqPPSend ({0})", nReturn));
                }
            }
            public class S7F4Args : EventArgs
            {
                public long ACKC7 = 0x00;
            }
            public static event EventHandler<S7F4Args> OnReciveS7F4Event;
            public static void OnReciveS7F4ProcessProgramAck(string sPpid, long ACKC7)
            {
                    //ACKC7
                    //0 - Accepted
                    //1 - Permission not granted
                    //2 - length error
                    //3 - matrix overflow
                    //4 - PPID not found
                    //5 - unsupported mode
                    //6 - initiated for asynchronous completion
                    //7 - storage limit error

                string sLog = String.Format("[XGEM ==> EQ] OnGEMRspPPSend : Ppid({0}), Result({1})", sPpid, ACKC7);
                AddMessage(sLog);

                if (OnReciveS7F4Event != null)
                {
                    S7F4Args args = new S7F4Args();
                    args.ACKC7 = ACKC7;
                    OnReciveS7F4Event(null, args);
                }
            }

            public static void SendS7F5ProcessProgramRequest(string sPpid)
            {
                long nReturn = 0;
                sPpid = "PPID001";
                nReturn = mXGem.GEMReqPP(sPpid);
                if (nReturn == 0)
                {
                    AddMessage("[EQ ==> XGEM] GEMReqPP successfully");
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMReqPP ({0})", nReturn));
                }
            }
            public class S7F6Args : EventArgs
            {
                public string Body = string.Empty;
            }
            public static event EventHandler<S7F6Args> OnReciveS7F6Event;
            public static void OnReciveS7F6ProcessProgramData(string sPpid, byte[] psBody)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMRspPP : Ppid({0}), Body({1})", sPpid, psBody);
                AddMessage(sLog);
                
                if (OnReciveS7F4Event != null)
                {
                    S7F6Args args = new S7F6Args();
                    char[] Tmp = new char[psBody.Length];
                    for (int i = 0x00; i < psBody.Length; i++)
                    {
                        Tmp[i] = (char)psBody[i];
                    }
                    args.Body = new string(Tmp);
                    OnReciveS7F6Event(null, args);
                }
            }

            public static void SendS7F23FormattedProcessProgramSend(string sPpid, string sMdln, string sSoftRev, Dictionary<string, List<string>> Body)
            {
                long nReturn = 0;
                long nCount = Body.Count;
                string[] saCCodes = new string[Body.Count];
                long[] naPCount = new long[Body.Count];
                List<string> Tmp = new List<string>();
                for (int i = 0x00; i < Body.Count; i++)
                {
                    saCCodes[i] = Body.ElementAt(i).Key;
                    naPCount[i] = Body.ElementAt(i).Value.Count;
                    for (int j = 0x00; j < naPCount[i]; j++)
                    {
                        string str = Body.ElementAt(i).Value[j];
                        Tmp.Add(str);
                    }
                }
                string[] saPNames = Tmp.ToArray();

                nReturn = mXGem.GEMReqPPFmtSend(sPpid, sMdln, sSoftRev, nCount, saCCodes, naPCount, saPNames);
                if (nReturn == 0)
                {
                    AddMessage("[EQ ==> XGEM] GEMReqPPFmtSend successfully");
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMReqPPFmtSend ({0})", nReturn));
                } 
            }
            public class S7F24Args : EventArgs
            {
                public long ACKC7 = 0x00;
            }
            public static event EventHandler<S7F24Args> OnReciveS7F24Event;
            public static void OnReciveS7F24FormattedProcessProgramAck(string sPpid, long ACKC7)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMRspPPFmtSend : Ppid({0}), ACKC7({1})", sPpid, ACKC7);
                AddMessage(sLog);
                if (OnReciveS7F24Event != null)
                {
                    S7F24Args args = new S7F24Args();
                    args.ACKC7 = ACKC7;
                    OnReciveS7F24Event(null, args);
                }

            }

            public static void SendS7F25FormattedProcessProgramRequest(string sPpid)
            {
                long nReturn = 0;

                nReturn = mXGem.GEMReqPPFmt(sPpid);
                if (nReturn == 0)
                {
                    AddMessage("[EQ ==> XGEM] GEMReqPPFmt successfully");
                }
                else
                {
                    AddMessage(string.Format ("[EQ ==> XGEM] Fail to GEMReqPPFmt ({0})", nReturn));
                }
            }
            public class S7F26Args : EventArgs
            {
                public string Ppid = string.Empty;
                public string sMdln = string.Empty;
                public string sSoftRev = string.Empty;
                public Dictionary<string, List<string>> Body;
            }
            public static event EventHandler<S7F26Args> OnReciveS7F26Event;
            public static void OnReciveS7F26FormattedProcessProgramData(string sPpid, string sMdln, string sSoftRev, long nCount, string[] psCCode, long[] pnParamCount, string[] psParamNames)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMRspPPFmt : Ppid({0})", sPpid);
                AddMessage(sLog);

                Dictionary<string, List<string>> Body = new Dictionary<string, List<string>>();
                int Idx = 0x00;
                for (int i = 0x00; i < nCount; i++)
                {
                    List<string> Tmp = new List<string>();
                    string Code = psCCode[i];
                    long Cnt = pnParamCount[i];
                    for (int j = 0x00; j < Cnt; j++)
                    {
                        Tmp.Add(psParamNames[Idx]);
                        Idx++;
                    }

                    Body.Add(Code, Tmp);
                }

                if (OnReciveS7F26Event != null)
                {
                    S7F26Args args = new S7F26Args();
                    args.Ppid = sPpid;
                    args.sMdln = sMdln;
                    args.sSoftRev = sSoftRev;
                    args.Body = Body;
                    OnReciveS7F26Event(null, args);
                }
            }
           
            
            #endregion

            #region Host -> EQP
            public class S7F1Args : EventArgs
            {
                public long SystemByte = 0x00;
                public string sPpid = string.Empty;
                public long nLength = 0x00;
            }
            public static event EventHandler<S7F1Args> OnReciveS7F1Event;
            public static void OnReciveS7F1ProcessProgramLoadInquire(long nSystemByte, string sPpid, long nLength)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqPPLoadInquire : Ppid({0}), ", sPpid);
                AddMessage(sLog);
                if (OnReciveS7F1Event != null)
                {
                    S7F1Args args = new S7F1Args();
                    args.SystemByte = nSystemByte;
                    args.sPpid = sPpid;
                    args.nLength = nLength;
                    OnReciveS7F1Event(null, args);
                }
                else
                {
                    SendS7F2ProcessProgramLoadGrant(nSystemByte, sPpid, 0);
                }
            }
            public static void SendS7F2ProcessProgramLoadGrant(long nSystemByte, string sPpid, long PPGNT)
            {
                //PPGNT
                //0 - Ok
                //1 - already have
                //2 - no space
                //3 - invalid PPID
                //4 - busy, try later
                //5 - will not accept
                //6 - other error
                long nReturn = 0;
                nReturn = mXGem.GEMRspPPLoadInquire(nSystemByte, sPpid, PPGNT);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspPPLoadInquire : Ppid({0}), ", sPpid);
                AddMessage(sLog);
            }

            public class S7F3Args : EventArgs
            {
                public long SystemByte = 0x00;
                public string sPpid = string.Empty;
                public string Body = string.Empty;
            }
            public static event EventHandler<S7F3Args> OnReciveS7F3Event;
            public static void OnReciveS7F3ProcessProgramSend(long nSystemByte, string sPpid, byte[] psBody)
            {
                
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqPPSend : Ppid({0}), Body({1})", sPpid, psBody);
                AddMessage(sLog);
                if (OnReciveS7F1Event != null)
                {
                    S7F3Args args = new S7F3Args();
                    args.SystemByte = nSystemByte;
                    args.sPpid = sPpid;
                    char[] Tmp = new char[psBody.Length];
                    for (int i = 0x00; i < psBody.Length; i++)
                    {
                        Tmp[i] = (char)psBody[i];
                    }
                    args.Body = new string(Tmp);
                    OnReciveS7F3Event(null, args);
                    
                }
                else
                {
                    SendS7F4ProcessProgramAck(nSystemByte, sPpid, 0);
                }
            }
            public static void SendS7F4ProcessProgramAck(long nSystemByte, string sPpid, long ACKC7)
            {
                long nReturn = 0;
                nReturn = mXGem.GEMRspPPSend(nSystemByte, sPpid, ACKC7);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspPPSend : Ppid({0}), ", sPpid);
                AddMessage(sLog);
            }

            public class S7F5Args : EventArgs
            {
                public long SystemByte = 0x00;
                public string sPpid = string.Empty;
            }
            public static event EventHandler<S7F5Args> OnReciveS7F5Event;
            public static void OnReciveS7F5ProcessProgramRequest(long nSystemByte, string sPpid)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqPP : Ppid({0})", sPpid);
                AddMessage(sLog);


                if (OnReciveS7F5Event != null)
                {
                    S7F5Args args = new S7F5Args();
                    args.SystemByte = nSystemByte;
                    args.sPpid = sPpid;
                    OnReciveS7F5Event(null, args);
                }
                else 
                {
                    string sBody = "PPbody";
                    SendS7F6ProcessProgramData(nSystemByte, sPpid, sBody);
                }
            }
            public static void SendS7F6ProcessProgramData(long nSystemByte, string sPpid, string sBody)
            {
                long nReturn = 0;
                char[] temp = sBody.ToArray();
                byte[] psBody = new byte[temp.Length];
                for (int i = 0x00; i < temp.Length; i++)
                {
                    psBody[i] = (byte)temp[i];
                }

                nReturn = mXGem.GEMRspPP(nSystemByte, sPpid, psBody);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspPP : Ppid({0}), Body({1})", sPpid, psBody);
                AddMessage(sLog);
            }

            public class S7F17Args : EventArgs
            {
                public long SystemByte = 0x00;
                public string[] psPpid;
            }
            public static event EventHandler<S7F17Args> OnReciveS7F17Event;
            public static void OnReciveS7F17DeleteProcessProgramSend(long nSystemByte, long nCount, string[] psPpid)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqPPDelete");
                AddMessage(sLog);

                string[] psTemp = new string[nCount];
                for (int i = 0; i < nCount; i++)
                {
                    psTemp[i] = psPpid[i];
                    sLog = String.Format("               Ppid: {0}", psPpid[i]);
                    AddMessage(sLog);
                }
                if (OnReciveS7F17Event != null)
                {
                    S7F17Args args = new S7F17Args();
                    args.SystemByte = nSystemByte;
                    args.psPpid = psPpid;
                    OnReciveS7F17Event(null, args);
                }
                else
                {
                    SendS7F18DeleteProcessProgramAck(nSystemByte, psTemp, 0);
                }
            }
            public static void SendS7F18DeleteProcessProgramAck(long nSystemByte, string[] sPpid, long ACKC7)
            {
                //ACKC7
                //0 - Accepted
                //1 - Permission not granted
                //2 - length error
                //3 - matrix overflow
                //4 - PPID not found
                //5 - unsupported mode
                //6 - initiated for asynchronous completion
                //7 - storage limit error

                long nReturn = 0;
                nReturn = mXGem.GEMRspPPDelete(nSystemByte, sPpid.Length, sPpid, ACKC7);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspPPDelete");
                AddMessage(sLog);
            }

            public class S7F19Args : EventArgs
            {
                public long nSystemByte = 0x00;
            }
            public static event EventHandler<S7F19Args> OnReciveS7F19Event;
            public static void OnReciveS7F19CurrentEPPDRequest(long nSystemByte)
            {
                //throw new Exception("The method or operation is not implemented.");
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqPPList");
                AddMessage(sLog);

                if (OnReciveS7F19Event != null)
                {
                    S7F19Args args = new S7F19Args();
                    args.nSystemByte = nSystemByte;
                    OnReciveS7F19Event(null, args);
                }
                else
                {
                    string[] saPpids = new string[2];
                    saPpids[0] = "PPID001";
                    saPpids[1] = "PPID002";

                    SendS7F20CurrentEPPDRequest(nSystemByte, saPpids);
                }
            }
            public static void SendS7F20CurrentEPPDRequest(long nSystemByte, string[] saPpids)
            {
                long nReturn = 0;
                nReturn = mXGem.GEMRspPPList(nSystemByte, saPpids.Length, saPpids);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspPPList");
                AddMessage(sLog);
            }


            public class S7F23Args : EventArgs
            {
                public long SystemByte = 0x00;
                public string sPpid = string.Empty;
                public string sMdln = string.Empty;
                public string sSoftRev = string.Empty;
                public Dictionary<string, List<string>> Body;
            }
            public static event EventHandler<S7F23Args> OnReciveS7F23Event;
            public static void OnReciveS7F23FormattedProcessProgramSend(long nSystemByte, string sPpid, string sMdln, string sSoftRev, long nCount, string[] psCCode, long[] pnParamCount, string[] psParamNames)
            {
                //throw new Exception("The method or operation is not implemented.");
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqPPFmtSend => Ppid:{0}, Mdln:{1}, SoftRev:{2}", sPpid, sMdln, sSoftRev);
                AddMessage(sLog);
                if (OnReciveS7F23Event != null)
                {
                    S7F23Args args = new S7F23Args();
                    args.SystemByte = nSystemByte;
                    args.sPpid = sPpid;
                    args.sMdln = sMdln;
                    args.sSoftRev = sSoftRev; 

                    Dictionary<string, List<string>> Body = new Dictionary<string, List<string>>();
                    int Idx = 0x00;
                    for (int i = 0x00; i < nCount; i++)
                    {
                        List<string> Tmp = new List<string>();
                        string Code = psCCode[i];
                        long Cnt = pnParamCount[i];
                        for (int j = 0x00; j < Cnt; j++)
                        {
                            Tmp.Add(psParamNames[Idx]);
                            Idx++;
                        }

                        Body.Add(Code, Tmp);
                    }
                    args.Body = Body;
                    OnReciveS7F23Event(null, args);
                    
                }
                else
                {
                    SendS7F24FormattedProcessProgramAck(nSystemByte, sPpid, 0);
                }
                
            }
            public static void SendS7F24FormattedProcessProgramAck(long nSystemByte, string sPpid, long ACKC7)
            {
                //ACKC7
                //0 - Accepted
                //1 - Permission not granted
                //2 - length error
                //3 - matrix overflow
                //4 - PPID not found
                //5 - unsupported mode
                //6 - initiated for asynchronous completion
                //7 - storage limit error

                long nReturn = 0;
                nReturn = mXGem.GEMRspPPFmtSend(nSystemByte, sPpid, ACKC7);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspPPFmtSend");
                AddMessage(sLog);
            }

            public class S7F25Args : EventArgs
            {
                public long SystemByte = 0x00;
                public string sPpid = string.Empty;
            }
            public static event EventHandler<S7F25Args> OnReciveS7F25Event;
            public static void OnReciveS7F25FormattedProcessProgramRequest(long nSystemByte, string sPpid)
            {
                //throw new Exception("The method or operation is not implemented.");
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqPPFmt : Ppid({0})", sPpid);
                AddMessage(sLog);

                if (OnReciveS7F25Event != null)
                {
                    S7F25Args args = new S7F25Args();
                    args.SystemByte = nSystemByte;
                    args.sPpid = sPpid;
                    OnReciveS7F25Event(null, args);
                }
                else
                {
                    string sMdln = "Mdln";
                    string sSoftRev = "001";
                    Dictionary<string, List<string>> Body = new Dictionary<string, List<string>>();
                    List<string> Temp1 = new List<string>();
                    Temp1.Add("Param001");
                    Temp1.Add("Param002");
                    Temp1.Add("Param003");
                    Temp1.Add("Param004");
                    Temp1.Add("Param005");
                    Body.Add("1", Temp1);
                    List<string> Temp2 = new List<string>();
                    Temp2.Add("Param006");
                    Temp2.Add("Param007");
                    Temp2.Add("Param008");
                    Temp2.Add("Param009");
                    Temp2.Add("Param010");
                    Body.Add("2", Temp2);
                    SendS7F26FormattedProcessProgramData(nSystemByte, sPpid, sMdln, sSoftRev, Body);
                }

            }
            public static void SendS7F26FormattedProcessProgramData(long nSystemByte, string sPpid, string sMdln, string sSoftRev, Dictionary<string, List<string>> Body)
            {
                long nReturn = 0;
                long nCount = Body.Count;
                string[] saCCodes = new string[Body.Count];
                long[] naPCount = new long[Body.Count];
                List<string> Tmp = new List<string>();
                for (int i = 0x00; i < Body.Count; i++)
                {
                    saCCodes[i] = Body.ElementAt(i).Key;
                    naPCount[i] = Body.ElementAt(i).Value.Count;
                    for (int j = 0x00; j < naPCount[i]; j++)
                    {
                        string str = Body.ElementAt(i).Value[j];
                        Tmp.Add(str);
                    }
                }
                string[] saPNames = Tmp.ToArray();

                nReturn = mXGem.GEMRspPPFmt(nSystemByte, sPpid, sMdln, sSoftRev, nCount, saCCodes, naPCount, saPNames);
                string sLog = String.Format("[EQ ==> XGEM] GEMRspPPFmtSend");
                AddMessage(sLog);
            }
            #endregion

            public static void SendS7F27PPVerifySend(string sPpid, long nCount, long[] naAck, string[] saSeqNo, string[] saError)
            {
                long nReturn = 0;

                nReturn = mXGem.GEMReqPPFmtVerification(sPpid, nCount, naAck, saSeqNo, saError);
                if (nReturn == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] GEMReqPPFmtVerification successfully"));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to GEMReqPPFmtVerification ({0})", nReturn));
                }
            }

            public class S7F28Args : EventArgs
            {
                public string sPpid = string.Empty;
                public long nResult = 0x00;
            }
            public static event EventHandler<S7F28Args> OnReciveS7F28Event;
            public static void OnReciveS7F28PPVerifyAck(string sPpid, long nResult)
            {
                //throw new Exception("The method or operation is not implemented.");
                string sLog = String.Format("[XGEM ==> EQ] OnGEMReqPPFmt : Ppid({0})", sPpid);
                AddMessage(sLog);

                if (OnReciveS7F28Event != null)
                {
                    S7F28Args args = new S7F28Args();
                    args.sPpid = sPpid;
                    args.nResult = nResult;
                    OnReciveS7F28Event(null, args);
                }

            }
        }

        public class Spool
        {
            public class SpoolStateArgs : EventArgs
            {
                public string State = string.Empty;
                public string LoadState = string.Empty;
                public string UnloadState = string.Empty;
                public string FullTime = string.Empty;
                public long MaxTransmit = 0x00;
                public long MsgNum = 0x00;
                public long TotalNum = 0x00;
                public long TransmitFail = 0x00;
            }
            public static event EventHandler<SpoolStateArgs> OnSpoolStateChangeEvent;
            public static void OnGEMSpoolStateChanged(long nState, long nLoadState, long nUnloadState, string sFullTime, long nMaxTransmit, long nMsgNum, long nTotalNum, long nTransmitFail)
            {
                string sLog = String.Format("[XGEM ==> EQ] OnGEMSpoolStateChanged => State:{0}, LoadState:{1}, UnloadState:{2}, FullTime:{3}, MaxTransmit:{4}, MsgNum:{5}, TotalNum:{6}, TransmitFail:{7}",
                                nState, nLoadState, nUnloadState, sFullTime, nMaxTransmit, nMsgNum, nTotalNum, nTransmitFail);


                if (OnSpoolStateChangeEvent == null)
                {
                    SpoolStateArgs args = new SpoolStateArgs();
                    if (nState == 0x00) args.State = "INACTIVE";
                    else args.State = "ACTIVE";
                    if (nLoadState == 0x00) args.State = "LD NOT FULL";
                    else args.State = "LD FULL ";
                    if (nUnloadState == 0x00) args.State = "NO OUTPUT";
                    else if (nUnloadState == 0x01) args.State = "TRANSMIT";
                    else args.State = "PURGE";

                    args.FullTime = sFullTime;
                    args.MaxTransmit = nMaxTransmit;
                    args.MsgNum = nMsgNum;
                    args.TotalNum = nTotalNum;
                    args.TransmitFail = nTransmitFail;
                    OnSpoolStateChangeEvent(null, args);
                }
                
                AddMessage(sLog);
            }

        }

        #region User defined message ...

        public class Userdefinedmessage
        {

            public static void SendS1F8(long nSystemByte)
            {
                long nReturn = 0;
                long nObjId = 0;
                long nS = 0;
                long nF = 0;

                string Temperature = string.Empty;
                VariableData.GetVariable("ChamberTemperature", ref Temperature);
                string Pressure = string.Empty;
                VariableData.GetVariable("ChamberPressure", ref Pressure);

                mXGem.MakeObject(ref nObjId);
                // Setting values
                mXGem.SetListItem(nObjId, 2);
                mXGem.SetListItem(nObjId, 2);   //  L 10
                mXGem.SetStringItem(nObjId, "ChamberTemperature");
                mXGem.SetStringItem(nObjId, Temperature);
                mXGem.SetListItem(nObjId, 2);   //  L 10
                mXGem.SetStringItem(nObjId, "ChamberPressure");
                mXGem.SetStringItem(nObjId, Pressure);
                

                nS = 1; nF = 8;
                nReturn = mXGem.SendSECSMessage(nObjId, nS, nF, nSystemByte);
                if (nReturn == 0)
                {
                    AddMessage(String.Format("[EQ ==> XGEM] S1F8 successfully ({0})", nReturn));
                }
                else
                {
                    AddMessage(String.Format("[EQ ==> XGEM] Fail to S1F8 ({0})", nReturn));
                }
            }

            public static void SendS101F101()
            {
                long nReturn = 0;
                long nObjId = 0;
                long nS = 0;
                long nF = 0;
                long nSysbyte = 0;

                sbyte nI1 = -128;
                short nI2 = -32768;
                int nI4 = -2147483648;
                int nI8 = -2147483648;
                byte nU1 = 255;
                ushort lU2 = 65535;
                uint nU4 = 4294967295;
                uint nU8 = 4294967295;
                float rF4 = 1234.567f;
                double rF8 = 123456789.87654321;
                bool nBool = true;
                byte nBinary = 10;
                string sAscii = "STRING; XGemPro Sample";

                mXGem.MakeObject(ref nObjId);
                // Setting values
                mXGem.SetListItem(nObjId, 2);
                    mXGem.SetListItem(nObjId, 10);   //  L 10
                    mXGem.SetInt1Item(nObjId, nI1);
                    mXGem.SetInt2Item(nObjId, nI2);
                    mXGem.SetInt4Item(nObjId, nI4);
                    mXGem.SetInt4Item(nObjId, nI8);
                    mXGem.SetUint1Item(nObjId, nU1);
                    mXGem.SetUint2Item(nObjId, lU2);
                    mXGem.SetUint4Item(nObjId, nU4);
                    mXGem.SetUint4Item(nObjId, nU8);
                    mXGem.SetFloat4Item(nObjId, rF4);
                    mXGem.SetFloat8Item(nObjId, rF8);

                    mXGem.SetListItem(nObjId, 3);    //  L 4
                        mXGem.SetStringItem(nObjId, sAscii);
                        mXGem.SetBinaryItem(nObjId, nBinary);
                        mXGem.SetBoolItem(nObjId, nBool);

                nS = 101; nF = 101; nSysbyte = 0;
                nReturn = mXGem.SendSECSMessage(nObjId, nS, nF, nSysbyte);
                if (nReturn == 0)
                {
                    AddMessage(String.Format("[EQ ==> XGEM] S101F101 successfully ({0})", nReturn));
                }
                else
                {
                    AddMessage(String.Format("[EQ ==> XGEM] Fail to S101F101 ({0})", nReturn));
                }
            }

            public static void SendS101F102(long nSystemByte)
            {
                long nReturn = 0;
                long nObjectID = 0;
                long nStream = 101;
                long nFunction = 102;
                mXGem.MakeObject(ref nObjectID);
                byte[] pnBinary = new byte[1];
                pnBinary[0] = 0;
                mXGem.SetBinaryItem(nObjectID, pnBinary);
                
                nReturn = mXGem.SendSECSMessage(nObjectID, nStream, nFunction, nSystemByte);
                if (nReturn == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Reply S101F102 successfully"));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to reply S101F102 ({0})", nReturn));
                }
            }

            public static void SendS101F103()
            {
                long nReturn = 0;
                long nObjId = 0;
                long nS = 0;
                long nF = 0;
                long nSysbyte = 0;

                int MAX_ARRAY = 7;
                sbyte[] VALUE_I1_ARR = new sbyte[MAX_ARRAY];
                short[] VALUE_I2_ARR = new short[MAX_ARRAY];
                int[] VALUE_I4_ARR = new int[MAX_ARRAY];
                int[] VALUE_I8_ARR = new int[MAX_ARRAY];
                byte[] VALUE_U1_ARR = new byte[MAX_ARRAY];
                ushort[] VALUE_U2_ARR = new ushort[MAX_ARRAY];
                uint[] VALUE_U4_ARR = new uint[MAX_ARRAY];
                uint[] VALUE_U8_ARR = new uint[MAX_ARRAY];
                float[] VALUE_F4_ARR = new float[MAX_ARRAY];
                double[] VALUE_F8_ARR = new double[MAX_ARRAY];
                bool[] VALUE_BOOL_ARR = new bool[MAX_ARRAY];
                byte[] VALUE_BINARY_ARR = new byte[MAX_ARRAY];
                string VALUE_STRING = "STRING; XGemPro Sample";
                mXGem.MakeObject(ref nObjId);
                // Setting values
                mXGem.SetListItem(nObjId, 13);
                mXGem.SetBoolItem(nObjId, VALUE_BOOL_ARR);
                mXGem.SetBinaryItem(nObjId, VALUE_BINARY_ARR);
                mXGem.SetUint1Item(nObjId, VALUE_U1_ARR);
                mXGem.SetUint2Item(nObjId, VALUE_U2_ARR);
                mXGem.SetUint4Item(nObjId, VALUE_U4_ARR);
                mXGem.SetUint4Item(nObjId, VALUE_U8_ARR);
                mXGem.SetInt1Item(nObjId, VALUE_I1_ARR);
                mXGem.SetInt2Item(nObjId, VALUE_I2_ARR);
                mXGem.SetInt4Item(nObjId, VALUE_I4_ARR);
                mXGem.SetInt4Item(nObjId, VALUE_I8_ARR);
                mXGem.SetFloat4Item(nObjId, VALUE_F4_ARR);
                mXGem.SetFloat8Item(nObjId, VALUE_F8_ARR);
                mXGem.SetStringItem(nObjId, VALUE_STRING);

                nS = 101; nF = 103; nSysbyte = 0;
                nReturn = mXGem.SendSECSMessage(nObjId, nS, nF, nSysbyte);
                if (nReturn == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] S101F103 successfully ({0})", nReturn));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to S101F103 ({0})", nReturn));
                }
            }

            public static void SendS101F104(long nSystemByte)
            {
                long nReturn = 0;
                long nObjectID = 0;
                long nStream = 101;
                long nFunction = 104;

                mXGem.MakeObject(ref nObjectID);
                byte[] pnU1 = new byte[] { 1 };
                mXGem.SetUint1Item(nObjectID, pnU1);

                nReturn = mXGem.SendSECSMessage(nObjectID, nStream, nFunction, nSystemByte);
                if (nReturn == 0)
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Reply S101F104 successfully"));
                }
                else
                {
                    AddMessage(string.Format("[EQ ==> XGEM] Fail to reply S101F104 ({0})", nReturn));
                }
            }

        }
        #endregion
    }
}
