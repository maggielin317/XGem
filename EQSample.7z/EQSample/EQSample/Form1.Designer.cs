﻿namespace EQSample
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbGemRCmd = new System.Windows.Forms.TabPage();
            this.rtbRcmdParam = new System.Windows.Forms.RichTextBox();
            this.lbRcmdTitle = new System.Windows.Forms.Label();
            this.tbEvent = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.tbVid1018 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbVid1019 = new System.Windows.Forms.TextBox();
            this.btnSetSv = new System.Windows.Forms.Button();
            this.btnSendEvent124 = new System.Windows.Forms.Button();
            this.btnSendCEID114 = new System.Windows.Forms.Button();
            this.btnSendCEID113 = new System.Windows.Forms.Button();
            this.btnSendCEID112 = new System.Windows.Forms.Button();
            this.tbpMaterialMovement = new System.Windows.Forms.TabPage();
            this.tbSendCeid12 = new System.Windows.Forms.Button();
            this.tbSendCeid11 = new System.Windows.Forms.Button();
            this.tbSetVid33 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.tbVid33 = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnAlarmClear = new System.Windows.Forms.Button();
            this.btnAlarmDetect = new System.Windows.Forms.Button();
            this.tbALID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabTerminalServices = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.tbMessageFromHost = new System.Windows.Forms.TextBox();
            this.tbTermialMessageTID = new System.Windows.Forms.TextBox();
            this.lbSendTerminalMessageTitle = new System.Windows.Forms.Label();
            this.tbSendTermialMessage = new System.Windows.Forms.TextBox();
            this.lbTermialMessageTID = new System.Windows.Forms.Label();
            this.mbtnTerminalMessageSend = new System.Windows.Forms.Button();
            this.tabEquipmentConstants = new System.Windows.Forms.TabPage();
            this.rtbNewEcv = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbECID = new System.Windows.Forms.TextBox();
            this.tbECV = new System.Windows.Forms.TextBox();
            this.btnSetECV = new System.Windows.Forms.Button();
            this.tbVariableDataCollection = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.tbVidName = new System.Windows.Forms.TextBox();
            this.btnSetVariableByName = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbVid = new System.Windows.Forms.TextBox();
            this.tbVariableValue = new System.Windows.Forms.TextBox();
            this.btnSetVariable = new System.Windows.Forms.Button();
            this.tbClock = new System.Windows.Forms.TabPage();
            this.rtbClock = new System.Windows.Forms.RichTextBox();
            this.btnReqHostGetDateTime = new System.Windows.Forms.Button();
            this.tbpProcessProgram = new System.Windows.Forms.TabPage();
            this.rtbPP = new System.Windows.Forms.RichTextBox();
            this.btnSendS7F27PPFmtVerification = new System.Windows.Forms.Button();
            this.btnSendS7F25FmtPPRequest = new System.Windows.Forms.Button();
            this.btnSendS7F23FmtPPSend = new System.Windows.Forms.Button();
            this.btnSendS7F5PPRequest = new System.Windows.Forms.Button();
            this.btnSendS7F3PPSend = new System.Windows.Forms.Button();
            this.btnSendS7F1PPLoadInquire = new System.Windows.Forms.Button();
            this.btnSetPPFmtChanged = new System.Windows.Forms.Button();
            this.btnSetPPChanged = new System.Windows.Forms.Button();
            this.tbSpool = new System.Windows.Forms.TabPage();
            this.rtbSpooling = new System.Windows.Forms.RichTextBox();
            this.tbpUserDefineMessage = new System.Windows.Forms.TabPage();
            this.btnS101F103 = new System.Windows.Forms.Button();
            this.btnS101F101 = new System.Windows.Forms.Button();
            this.lstMsg = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.m_btnXGemClose = new System.Windows.Forms.Button();
            this.btnXGemInitialize = new System.Windows.Forms.Button();
            this.btnXGemStop = new System.Windows.Forms.Button();
            this.btnXGemStart = new System.Windows.Forms.Button();
            this.tbCfgFileName = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btnCommunicationEnable = new System.Windows.Forms.Button();
            this.btnCommunicationDisable = new System.Windows.Forms.Button();
            this.tbCommState = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btnReqHostOffline = new System.Windows.Forms.Button();
            this.btnOffline = new System.Windows.Forms.Button();
            this.btnLocal = new System.Windows.Forms.Button();
            this.btnRemote = new System.Windows.Forms.Button();
            this.tbControlState = new System.Windows.Forms.TextBox();
            this.tmrInfo = new System.Windows.Forms.Timer(this.components);
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.tbProcessingState = new System.Windows.Forms.TextBox();
            this.m_cmbProcessingState = new System.Windows.Forms.ComboBox();
            this.btnProcessingState = new System.Windows.Forms.Button();
            this.btnGetSv = new System.Windows.Forms.Button();
            this.btnGetECV = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tbGemRCmd.SuspendLayout();
            this.tbEvent.SuspendLayout();
            this.tbpMaterialMovement.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabTerminalServices.SuspendLayout();
            this.tabEquipmentConstants.SuspendLayout();
            this.tbVariableDataCollection.SuspendLayout();
            this.tbClock.SuspendLayout();
            this.tbpProcessProgram.SuspendLayout();
            this.tbSpool.SuspendLayout();
            this.tbpUserDefineMessage.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbGemRCmd);
            this.tabControl1.Controls.Add(this.tbEvent);
            this.tabControl1.Controls.Add(this.tbpMaterialMovement);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabTerminalServices);
            this.tabControl1.Controls.Add(this.tabEquipmentConstants);
            this.tabControl1.Controls.Add(this.tbVariableDataCollection);
            this.tabControl1.Controls.Add(this.tbClock);
            this.tabControl1.Controls.Add(this.tbpProcessProgram);
            this.tabControl1.Controls.Add(this.tbSpool);
            this.tabControl1.Controls.Add(this.tbpUserDefineMessage);
            this.tabControl1.ItemSize = new System.Drawing.Size(200, 50);
            this.tabControl1.Location = new System.Drawing.Point(213, 321);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1050, 437);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 0;
            // 
            // tbGemRCmd
            // 
            this.tbGemRCmd.Controls.Add(this.rtbRcmdParam);
            this.tbGemRCmd.Controls.Add(this.lbRcmdTitle);
            this.tbGemRCmd.Location = new System.Drawing.Point(4, 104);
            this.tbGemRCmd.Name = "tbGemRCmd";
            this.tbGemRCmd.Padding = new System.Windows.Forms.Padding(3);
            this.tbGemRCmd.Size = new System.Drawing.Size(1042, 329);
            this.tbGemRCmd.TabIndex = 0;
            this.tbGemRCmd.Text = "Remote Commend";
            this.tbGemRCmd.UseVisualStyleBackColor = true;
            // 
            // rtbRcmdParam
            // 
            this.rtbRcmdParam.Location = new System.Drawing.Point(217, 49);
            this.rtbRcmdParam.Name = "rtbRcmdParam";
            this.rtbRcmdParam.Size = new System.Drawing.Size(378, 262);
            this.rtbRcmdParam.TabIndex = 2;
            this.rtbRcmdParam.Text = "";
            // 
            // lbRcmdTitle
            // 
            this.lbRcmdTitle.Location = new System.Drawing.Point(6, 49);
            this.lbRcmdTitle.Name = "lbRcmdTitle";
            this.lbRcmdTitle.Size = new System.Drawing.Size(173, 24);
            this.lbRcmdTitle.TabIndex = 0;
            this.lbRcmdTitle.Text = "RCMD";
            this.lbRcmdTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbEvent
            // 
            this.tbEvent.Controls.Add(this.label8);
            this.tbEvent.Controls.Add(this.tbVid1018);
            this.tbEvent.Controls.Add(this.label1);
            this.tbEvent.Controls.Add(this.tbVid1019);
            this.tbEvent.Controls.Add(this.btnSetSv);
            this.tbEvent.Controls.Add(this.btnSendEvent124);
            this.tbEvent.Controls.Add(this.btnSendCEID114);
            this.tbEvent.Controls.Add(this.btnSendCEID113);
            this.tbEvent.Controls.Add(this.btnSendCEID112);
            this.tbEvent.Location = new System.Drawing.Point(4, 54);
            this.tbEvent.Name = "tbEvent";
            this.tbEvent.Padding = new System.Windows.Forms.Padding(3);
            this.tbEvent.Size = new System.Drawing.Size(1042, 379);
            this.tbEvent.TabIndex = 1;
            this.tbEvent.Text = "Event";
            this.tbEvent.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(367, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(193, 42);
            this.label8.TabIndex = 24;
            this.label8.Text = "ChamberTemperature VID 1018：";
            // 
            // tbVid1018
            // 
            this.tbVid1018.Location = new System.Drawing.Point(579, 37);
            this.tbVid1018.Name = "tbVid1018";
            this.tbVid1018.Size = new System.Drawing.Size(129, 26);
            this.tbVid1018.TabIndex = 23;
            this.tbVid1018.Text = "50";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(367, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 42);
            this.label1.TabIndex = 22;
            this.label1.Text = "ChamberPressure VID 1019：";
            // 
            // tbVid1019
            // 
            this.tbVid1019.Location = new System.Drawing.Point(579, 83);
            this.tbVid1019.Name = "tbVid1019";
            this.tbVid1019.Size = new System.Drawing.Size(129, 26);
            this.tbVid1019.TabIndex = 21;
            this.tbVid1019.Text = "6";
            // 
            // btnSetSv
            // 
            this.btnSetSv.BackColor = System.Drawing.Color.White;
            this.btnSetSv.Location = new System.Drawing.Point(411, 133);
            this.btnSetSv.Name = "btnSetSv";
            this.btnSetSv.Size = new System.Drawing.Size(202, 57);
            this.btnSetSv.TabIndex = 20;
            this.btnSetSv.Text = "SetVariable";
            this.btnSetSv.UseVisualStyleBackColor = false;
            this.btnSetSv.Click += new System.EventHandler(this.btnSetSv_Click);
            // 
            // btnSendEvent124
            // 
            this.btnSendEvent124.BackColor = System.Drawing.Color.White;
            this.btnSendEvent124.Location = new System.Drawing.Point(411, 215);
            this.btnSendEvent124.Name = "btnSendEvent124";
            this.btnSendEvent124.Size = new System.Drawing.Size(202, 57);
            this.btnSendEvent124.TabIndex = 6;
            this.btnSendEvent124.Text = "Send CEID 124";
            this.btnSendEvent124.UseVisualStyleBackColor = false;
            this.btnSendEvent124.Click += new System.EventHandler(this.btnSendEvent124_Click);
            // 
            // btnSendCEID114
            // 
            this.btnSendCEID114.BackColor = System.Drawing.Color.White;
            this.btnSendCEID114.Location = new System.Drawing.Point(53, 188);
            this.btnSendCEID114.Name = "btnSendCEID114";
            this.btnSendCEID114.Size = new System.Drawing.Size(202, 57);
            this.btnSendCEID114.TabIndex = 5;
            this.btnSendCEID114.Text = "Send CEID 114";
            this.btnSendCEID114.UseVisualStyleBackColor = false;
            this.btnSendCEID114.Click += new System.EventHandler(this.btnSendCEID114_Click);
            // 
            // btnSendCEID113
            // 
            this.btnSendCEID113.BackColor = System.Drawing.Color.White;
            this.btnSendCEID113.Location = new System.Drawing.Point(53, 119);
            this.btnSendCEID113.Name = "btnSendCEID113";
            this.btnSendCEID113.Size = new System.Drawing.Size(202, 57);
            this.btnSendCEID113.TabIndex = 4;
            this.btnSendCEID113.Text = "Send CEID 113";
            this.btnSendCEID113.UseVisualStyleBackColor = false;
            this.btnSendCEID113.Click += new System.EventHandler(this.btnSendCEID113_Click);
            // 
            // btnSendCEID112
            // 
            this.btnSendCEID112.BackColor = System.Drawing.Color.White;
            this.btnSendCEID112.Location = new System.Drawing.Point(53, 52);
            this.btnSendCEID112.Name = "btnSendCEID112";
            this.btnSendCEID112.Size = new System.Drawing.Size(202, 57);
            this.btnSendCEID112.TabIndex = 3;
            this.btnSendCEID112.Text = "Send CEID 112";
            this.btnSendCEID112.UseVisualStyleBackColor = false;
            this.btnSendCEID112.Click += new System.EventHandler(this.btnSendCEID112_Click);
            // 
            // tbpMaterialMovement
            // 
            this.tbpMaterialMovement.Controls.Add(this.tbSendCeid12);
            this.tbpMaterialMovement.Controls.Add(this.tbSendCeid11);
            this.tbpMaterialMovement.Controls.Add(this.tbSetVid33);
            this.tbpMaterialMovement.Controls.Add(this.label10);
            this.tbpMaterialMovement.Controls.Add(this.tbVid33);
            this.tbpMaterialMovement.Location = new System.Drawing.Point(4, 54);
            this.tbpMaterialMovement.Name = "tbpMaterialMovement";
            this.tbpMaterialMovement.Padding = new System.Windows.Forms.Padding(3);
            this.tbpMaterialMovement.Size = new System.Drawing.Size(1042, 379);
            this.tbpMaterialMovement.TabIndex = 10;
            this.tbpMaterialMovement.Text = "Material Movement";
            this.tbpMaterialMovement.UseVisualStyleBackColor = true;
            // 
            // tbSendCeid12
            // 
            this.tbSendCeid12.BackColor = System.Drawing.Color.White;
            this.tbSendCeid12.Location = new System.Drawing.Point(419, 172);
            this.tbSendCeid12.Name = "tbSendCeid12";
            this.tbSendCeid12.Size = new System.Drawing.Size(297, 46);
            this.tbSendCeid12.TabIndex = 29;
            this.tbSendCeid12.Text = "Send CEID 12 Material Remove";
            this.tbSendCeid12.UseVisualStyleBackColor = false;
            this.tbSendCeid12.Click += new System.EventHandler(this.tbSendCeid12_Click);
            // 
            // tbSendCeid11
            // 
            this.tbSendCeid11.BackColor = System.Drawing.Color.White;
            this.tbSendCeid11.Location = new System.Drawing.Point(419, 115);
            this.tbSendCeid11.Name = "tbSendCeid11";
            this.tbSendCeid11.Size = new System.Drawing.Size(297, 46);
            this.tbSendCeid11.TabIndex = 28;
            this.tbSendCeid11.Text = "Send CEID 11 Material Received";
            this.tbSendCeid11.UseVisualStyleBackColor = false;
            this.tbSendCeid11.Click += new System.EventHandler(this.tbSendCeid11_Click);
            // 
            // tbSetVid33
            // 
            this.tbSetVid33.BackColor = System.Drawing.Color.White;
            this.tbSetVid33.Location = new System.Drawing.Point(419, 34);
            this.tbSetVid33.Name = "tbSetVid33";
            this.tbSetVid33.Size = new System.Drawing.Size(202, 57);
            this.tbSetVid33.TabIndex = 27;
            this.tbSetVid33.Text = "SetVariable";
            this.tbSetVid33.UseVisualStyleBackColor = false;
            this.tbSetVid33.Click += new System.EventHandler(this.tbSetVid33_Click);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(47, 52);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(152, 27);
            this.label10.TabIndex = 26;
            this.label10.Text = "Port ID VID 33：";
            // 
            // tbVid33
            // 
            this.tbVid33.Location = new System.Drawing.Point(205, 49);
            this.tbVid33.Name = "tbVid33";
            this.tbVid33.Size = new System.Drawing.Size(129, 26);
            this.tbVid33.TabIndex = 25;
            this.tbVid33.Text = "1";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnAlarmClear);
            this.tabPage1.Controls.Add(this.btnAlarmDetect);
            this.tabPage1.Controls.Add(this.tbALID);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Location = new System.Drawing.Point(4, 54);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1042, 379);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Alarm Management";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnAlarmClear
            // 
            this.btnAlarmClear.BackColor = System.Drawing.Color.White;
            this.btnAlarmClear.Location = new System.Drawing.Point(440, 102);
            this.btnAlarmClear.Name = "btnAlarmClear";
            this.btnAlarmClear.Size = new System.Drawing.Size(165, 27);
            this.btnAlarmClear.TabIndex = 7;
            this.btnAlarmClear.Text = "Alarm Clear";
            this.btnAlarmClear.UseVisualStyleBackColor = false;
            this.btnAlarmClear.Click += new System.EventHandler(this.btnAlarmClear_Click);
            // 
            // btnAlarmDetect
            // 
            this.btnAlarmDetect.BackColor = System.Drawing.Color.White;
            this.btnAlarmDetect.Location = new System.Drawing.Point(440, 46);
            this.btnAlarmDetect.Name = "btnAlarmDetect";
            this.btnAlarmDetect.Size = new System.Drawing.Size(165, 27);
            this.btnAlarmDetect.TabIndex = 6;
            this.btnAlarmDetect.Text = "Alarm Detect";
            this.btnAlarmDetect.UseVisualStyleBackColor = false;
            this.btnAlarmDetect.Click += new System.EventHandler(this.btnAlarmDetect_Click);
            // 
            // tbALID
            // 
            this.tbALID.Location = new System.Drawing.Point(241, 74);
            this.tbALID.Name = "tbALID";
            this.tbALID.Size = new System.Drawing.Size(150, 26);
            this.tbALID.TabIndex = 5;
            this.tbALID.Text = "1000";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(27, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 24);
            this.label2.TabIndex = 4;
            this.label2.Text = "ALID";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabTerminalServices
            // 
            this.tabTerminalServices.Controls.Add(this.label3);
            this.tabTerminalServices.Controls.Add(this.tbMessageFromHost);
            this.tabTerminalServices.Controls.Add(this.tbTermialMessageTID);
            this.tabTerminalServices.Controls.Add(this.lbSendTerminalMessageTitle);
            this.tabTerminalServices.Controls.Add(this.tbSendTermialMessage);
            this.tabTerminalServices.Controls.Add(this.lbTermialMessageTID);
            this.tabTerminalServices.Controls.Add(this.mbtnTerminalMessageSend);
            this.tabTerminalServices.Location = new System.Drawing.Point(4, 54);
            this.tabTerminalServices.Name = "tabTerminalServices";
            this.tabTerminalServices.Padding = new System.Windows.Forms.Padding(3);
            this.tabTerminalServices.Size = new System.Drawing.Size(1042, 379);
            this.tabTerminalServices.TabIndex = 3;
            this.tabTerminalServices.Text = "Terminal Services";
            this.tabTerminalServices.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(530, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 19);
            this.label3.TabIndex = 12;
            this.label3.Text = "Host Message :";
            // 
            // tbMessageFromHost
            // 
            this.tbMessageFromHost.Location = new System.Drawing.Point(518, 102);
            this.tbMessageFromHost.Multiline = true;
            this.tbMessageFromHost.Name = "tbMessageFromHost";
            this.tbMessageFromHost.Size = new System.Drawing.Size(341, 221);
            this.tbMessageFromHost.TabIndex = 11;
            this.tbMessageFromHost.Text = "Terminal Message Testing...";
            // 
            // tbTermialMessageTID
            // 
            this.tbTermialMessageTID.Location = new System.Drawing.Point(85, 23);
            this.tbTermialMessageTID.Name = "tbTermialMessageTID";
            this.tbTermialMessageTID.Size = new System.Drawing.Size(85, 26);
            this.tbTermialMessageTID.TabIndex = 10;
            this.tbTermialMessageTID.Text = "0";
            // 
            // lbSendTerminalMessageTitle
            // 
            this.lbSendTerminalMessageTitle.Location = new System.Drawing.Point(33, 80);
            this.lbSendTerminalMessageTitle.Name = "lbSendTerminalMessageTitle";
            this.lbSendTerminalMessageTitle.Size = new System.Drawing.Size(110, 19);
            this.lbSendTerminalMessageTitle.TabIndex = 9;
            this.lbSendTerminalMessageTitle.Text = "Message :";
            // 
            // tbSendTermialMessage
            // 
            this.tbSendTermialMessage.Location = new System.Drawing.Point(33, 102);
            this.tbSendTermialMessage.Multiline = true;
            this.tbSendTermialMessage.Name = "tbSendTermialMessage";
            this.tbSendTermialMessage.Size = new System.Drawing.Size(341, 221);
            this.tbSendTermialMessage.TabIndex = 8;
            this.tbSendTermialMessage.Text = "Terminal Message Testing...";
            // 
            // lbTermialMessageTID
            // 
            this.lbTermialMessageTID.Location = new System.Drawing.Point(29, 26);
            this.lbTermialMessageTID.Name = "lbTermialMessageTID";
            this.lbTermialMessageTID.Size = new System.Drawing.Size(65, 19);
            this.lbTermialMessageTID.TabIndex = 7;
            this.lbTermialMessageTID.Text = "TID :";
            // 
            // mbtnTerminalMessageSend
            // 
            this.mbtnTerminalMessageSend.BackColor = System.Drawing.Color.White;
            this.mbtnTerminalMessageSend.Location = new System.Drawing.Point(203, 21);
            this.mbtnTerminalMessageSend.Name = "mbtnTerminalMessageSend";
            this.mbtnTerminalMessageSend.Size = new System.Drawing.Size(147, 31);
            this.mbtnTerminalMessageSend.TabIndex = 6;
            this.mbtnTerminalMessageSend.Text = "Send Msg";
            this.mbtnTerminalMessageSend.UseVisualStyleBackColor = false;
            this.mbtnTerminalMessageSend.Click += new System.EventHandler(this.mbtnTerminalMessageSend_Click);
            // 
            // tabEquipmentConstants
            // 
            this.tabEquipmentConstants.Controls.Add(this.btnGetECV);
            this.tabEquipmentConstants.Controls.Add(this.rtbNewEcv);
            this.tabEquipmentConstants.Controls.Add(this.label5);
            this.tabEquipmentConstants.Controls.Add(this.label4);
            this.tabEquipmentConstants.Controls.Add(this.tbECID);
            this.tabEquipmentConstants.Controls.Add(this.tbECV);
            this.tabEquipmentConstants.Controls.Add(this.btnSetECV);
            this.tabEquipmentConstants.Location = new System.Drawing.Point(4, 104);
            this.tabEquipmentConstants.Name = "tabEquipmentConstants";
            this.tabEquipmentConstants.Padding = new System.Windows.Forms.Padding(3);
            this.tabEquipmentConstants.Size = new System.Drawing.Size(1042, 329);
            this.tabEquipmentConstants.TabIndex = 4;
            this.tabEquipmentConstants.Text = "Equipment Constants";
            this.tabEquipmentConstants.UseVisualStyleBackColor = true;
            // 
            // rtbNewEcv
            // 
            this.rtbNewEcv.Location = new System.Drawing.Point(562, 46);
            this.rtbNewEcv.Name = "rtbNewEcv";
            this.rtbNewEcv.Size = new System.Drawing.Size(378, 262);
            this.rtbNewEcv.TabIndex = 15;
            this.rtbNewEcv.Text = "";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(45, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 19);
            this.label5.TabIndex = 14;
            this.label5.Text = "Value:";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(45, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 19);
            this.label4.TabIndex = 13;
            this.label4.Text = "ECID :";
            // 
            // tbECID
            // 
            this.tbECID.Location = new System.Drawing.Point(123, 47);
            this.tbECID.Name = "tbECID";
            this.tbECID.Size = new System.Drawing.Size(129, 26);
            this.tbECID.TabIndex = 12;
            this.tbECID.Text = "4013";
            // 
            // tbECV
            // 
            this.tbECV.Location = new System.Drawing.Point(123, 98);
            this.tbECV.Name = "tbECV";
            this.tbECV.Size = new System.Drawing.Size(129, 26);
            this.tbECV.TabIndex = 11;
            this.tbECV.Text = "1000";
            // 
            // btnSetECV
            // 
            this.btnSetECV.BackColor = System.Drawing.Color.White;
            this.btnSetECV.Location = new System.Drawing.Point(49, 167);
            this.btnSetECV.Name = "btnSetECV";
            this.btnSetECV.Size = new System.Drawing.Size(181, 59);
            this.btnSetECV.TabIndex = 9;
            this.btnSetECV.Text = "Set ECV";
            this.btnSetECV.UseVisualStyleBackColor = false;
            this.btnSetECV.Click += new System.EventHandler(this.btnSetECV_Click);
            // 
            // tbVariableDataCollection
            // 
            this.tbVariableDataCollection.Controls.Add(this.btnGetSv);
            this.tbVariableDataCollection.Controls.Add(this.label9);
            this.tbVariableDataCollection.Controls.Add(this.tbVidName);
            this.tbVariableDataCollection.Controls.Add(this.btnSetVariableByName);
            this.tbVariableDataCollection.Controls.Add(this.label6);
            this.tbVariableDataCollection.Controls.Add(this.label7);
            this.tbVariableDataCollection.Controls.Add(this.tbVid);
            this.tbVariableDataCollection.Controls.Add(this.tbVariableValue);
            this.tbVariableDataCollection.Controls.Add(this.btnSetVariable);
            this.tbVariableDataCollection.Location = new System.Drawing.Point(4, 104);
            this.tbVariableDataCollection.Name = "tbVariableDataCollection";
            this.tbVariableDataCollection.Padding = new System.Windows.Forms.Padding(3);
            this.tbVariableDataCollection.Size = new System.Drawing.Size(1042, 329);
            this.tbVariableDataCollection.TabIndex = 5;
            this.tbVariableDataCollection.Text = "Variable Data";
            this.tbVariableDataCollection.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(282, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 19);
            this.label9.TabIndex = 23;
            this.label9.Text = "VID By Name";
            // 
            // tbVidName
            // 
            this.tbVidName.Location = new System.Drawing.Point(411, 44);
            this.tbVidName.Name = "tbVidName";
            this.tbVidName.Size = new System.Drawing.Size(206, 26);
            this.tbVidName.TabIndex = 22;
            this.tbVidName.Text = "TestVariable2";
            // 
            // btnSetVariableByName
            // 
            this.btnSetVariableByName.BackColor = System.Drawing.Color.White;
            this.btnSetVariableByName.Location = new System.Drawing.Point(347, 135);
            this.btnSetVariableByName.Name = "btnSetVariableByName";
            this.btnSetVariableByName.Size = new System.Drawing.Size(193, 27);
            this.btnSetVariableByName.TabIndex = 20;
            this.btnSetVariableByName.Text = "SetVariableByName";
            this.btnSetVariableByName.UseVisualStyleBackColor = false;
            this.btnSetVariableByName.Click += new System.EventHandler(this.btnSetVariableByName_Click);
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(152, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 19);
            this.label6.TabIndex = 19;
            this.label6.Text = "Value:";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(26, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 19);
            this.label7.TabIndex = 18;
            this.label7.Text = "VID :";
            // 
            // tbVid
            // 
            this.tbVid.Location = new System.Drawing.Point(104, 46);
            this.tbVid.Name = "tbVid";
            this.tbVid.Size = new System.Drawing.Size(129, 26);
            this.tbVid.TabIndex = 17;
            this.tbVid.Text = "1018";
            // 
            // tbVariableValue
            // 
            this.tbVariableValue.Location = new System.Drawing.Point(230, 90);
            this.tbVariableValue.Name = "tbVariableValue";
            this.tbVariableValue.Size = new System.Drawing.Size(129, 26);
            this.tbVariableValue.TabIndex = 16;
            this.tbVariableValue.Text = "60";
            // 
            // btnSetVariable
            // 
            this.btnSetVariable.BackColor = System.Drawing.Color.White;
            this.btnSetVariable.Location = new System.Drawing.Point(68, 135);
            this.btnSetVariable.Name = "btnSetVariable";
            this.btnSetVariable.Size = new System.Drawing.Size(165, 27);
            this.btnSetVariable.TabIndex = 15;
            this.btnSetVariable.Text = "SetSV";
            this.btnSetVariable.UseVisualStyleBackColor = false;
            this.btnSetVariable.Click += new System.EventHandler(this.btnSetVariable_Click);
            // 
            // tbClock
            // 
            this.tbClock.Controls.Add(this.rtbClock);
            this.tbClock.Controls.Add(this.btnReqHostGetDateTime);
            this.tbClock.Location = new System.Drawing.Point(4, 54);
            this.tbClock.Name = "tbClock";
            this.tbClock.Padding = new System.Windows.Forms.Padding(3);
            this.tbClock.Size = new System.Drawing.Size(1042, 379);
            this.tbClock.TabIndex = 6;
            this.tbClock.Text = "Clock";
            this.tbClock.UseVisualStyleBackColor = true;
            // 
            // rtbClock
            // 
            this.rtbClock.Location = new System.Drawing.Point(349, 24);
            this.rtbClock.Name = "rtbClock";
            this.rtbClock.Size = new System.Drawing.Size(378, 262);
            this.rtbClock.TabIndex = 3;
            this.rtbClock.Text = "";
            // 
            // btnReqHostGetDateTime
            // 
            this.btnReqHostGetDateTime.BackColor = System.Drawing.Color.White;
            this.btnReqHostGetDateTime.Location = new System.Drawing.Point(81, 46);
            this.btnReqHostGetDateTime.Name = "btnReqHostGetDateTime";
            this.btnReqHostGetDateTime.Size = new System.Drawing.Size(203, 65);
            this.btnReqHostGetDateTime.TabIndex = 1;
            this.btnReqHostGetDateTime.Text = "ReqHostGetDateTime";
            this.btnReqHostGetDateTime.UseVisualStyleBackColor = false;
            this.btnReqHostGetDateTime.Click += new System.EventHandler(this.btnReqHostGetDateTime_Click);
            // 
            // tbpProcessProgram
            // 
            this.tbpProcessProgram.Controls.Add(this.rtbPP);
            this.tbpProcessProgram.Controls.Add(this.btnSendS7F27PPFmtVerification);
            this.tbpProcessProgram.Controls.Add(this.btnSendS7F25FmtPPRequest);
            this.tbpProcessProgram.Controls.Add(this.btnSendS7F23FmtPPSend);
            this.tbpProcessProgram.Controls.Add(this.btnSendS7F5PPRequest);
            this.tbpProcessProgram.Controls.Add(this.btnSendS7F3PPSend);
            this.tbpProcessProgram.Controls.Add(this.btnSendS7F1PPLoadInquire);
            this.tbpProcessProgram.Controls.Add(this.btnSetPPFmtChanged);
            this.tbpProcessProgram.Controls.Add(this.btnSetPPChanged);
            this.tbpProcessProgram.Location = new System.Drawing.Point(4, 54);
            this.tbpProcessProgram.Name = "tbpProcessProgram";
            this.tbpProcessProgram.Padding = new System.Windows.Forms.Padding(3);
            this.tbpProcessProgram.Size = new System.Drawing.Size(1042, 379);
            this.tbpProcessProgram.TabIndex = 7;
            this.tbpProcessProgram.Text = "Process Program";
            this.tbpProcessProgram.UseVisualStyleBackColor = true;
            // 
            // rtbPP
            // 
            this.rtbPP.Location = new System.Drawing.Point(608, 36);
            this.rtbPP.Name = "rtbPP";
            this.rtbPP.Size = new System.Drawing.Size(378, 262);
            this.rtbPP.TabIndex = 16;
            this.rtbPP.Text = "";
            // 
            // btnSendS7F27PPFmtVerification
            // 
            this.btnSendS7F27PPFmtVerification.BackColor = System.Drawing.Color.White;
            this.btnSendS7F27PPFmtVerification.Location = new System.Drawing.Point(302, 150);
            this.btnSendS7F27PPFmtVerification.Name = "btnSendS7F27PPFmtVerification";
            this.btnSendS7F27PPFmtVerification.Size = new System.Drawing.Size(268, 51);
            this.btnSendS7F27PPFmtVerification.TabIndex = 15;
            this.btnSendS7F27PPFmtVerification.Text = "Send S7F27 PP Fmt Verification";
            this.btnSendS7F27PPFmtVerification.UseVisualStyleBackColor = false;
            this.btnSendS7F27PPFmtVerification.Click += new System.EventHandler(this.btnSendS7F27PPFmtVerification_Click);
            // 
            // btnSendS7F25FmtPPRequest
            // 
            this.btnSendS7F25FmtPPRequest.BackColor = System.Drawing.Color.White;
            this.btnSendS7F25FmtPPRequest.Location = new System.Drawing.Point(301, 75);
            this.btnSendS7F25FmtPPRequest.Name = "btnSendS7F25FmtPPRequest";
            this.btnSendS7F25FmtPPRequest.Size = new System.Drawing.Size(268, 51);
            this.btnSendS7F25FmtPPRequest.TabIndex = 14;
            this.btnSendS7F25FmtPPRequest.Text = "Send S7F25 Fmt PP Request";
            this.btnSendS7F25FmtPPRequest.UseVisualStyleBackColor = false;
            this.btnSendS7F25FmtPPRequest.Click += new System.EventHandler(this.btnSendS7F25FmtPPRequest_Click);
            // 
            // btnSendS7F23FmtPPSend
            // 
            this.btnSendS7F23FmtPPSend.BackColor = System.Drawing.Color.White;
            this.btnSendS7F23FmtPPSend.Location = new System.Drawing.Point(301, 24);
            this.btnSendS7F23FmtPPSend.Name = "btnSendS7F23FmtPPSend";
            this.btnSendS7F23FmtPPSend.Size = new System.Drawing.Size(268, 51);
            this.btnSendS7F23FmtPPSend.TabIndex = 13;
            this.btnSendS7F23FmtPPSend.Text = "Send S7F23 Fmt PP Send";
            this.btnSendS7F23FmtPPSend.UseVisualStyleBackColor = false;
            this.btnSendS7F23FmtPPSend.Click += new System.EventHandler(this.btnSendS7F23FmtPPSend_Click);
            // 
            // btnSendS7F5PPRequest
            // 
            this.btnSendS7F5PPRequest.BackColor = System.Drawing.Color.White;
            this.btnSendS7F5PPRequest.Location = new System.Drawing.Point(16, 252);
            this.btnSendS7F5PPRequest.Name = "btnSendS7F5PPRequest";
            this.btnSendS7F5PPRequest.Size = new System.Drawing.Size(268, 51);
            this.btnSendS7F5PPRequest.TabIndex = 12;
            this.btnSendS7F5PPRequest.Text = "Send S7F5 PP Request";
            this.btnSendS7F5PPRequest.UseVisualStyleBackColor = false;
            this.btnSendS7F5PPRequest.Click += new System.EventHandler(this.btnSendS7F5PPRequest_Click);
            // 
            // btnSendS7F3PPSend
            // 
            this.btnSendS7F3PPSend.BackColor = System.Drawing.Color.White;
            this.btnSendS7F3PPSend.Location = new System.Drawing.Point(16, 201);
            this.btnSendS7F3PPSend.Name = "btnSendS7F3PPSend";
            this.btnSendS7F3PPSend.Size = new System.Drawing.Size(268, 51);
            this.btnSendS7F3PPSend.TabIndex = 11;
            this.btnSendS7F3PPSend.Text = "Send S7F3 PP Send";
            this.btnSendS7F3PPSend.UseVisualStyleBackColor = false;
            this.btnSendS7F3PPSend.Click += new System.EventHandler(this.btnSendS7F3PPSend_Click);
            // 
            // btnSendS7F1PPLoadInquire
            // 
            this.btnSendS7F1PPLoadInquire.BackColor = System.Drawing.Color.White;
            this.btnSendS7F1PPLoadInquire.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendS7F1PPLoadInquire.Location = new System.Drawing.Point(16, 150);
            this.btnSendS7F1PPLoadInquire.Name = "btnSendS7F1PPLoadInquire";
            this.btnSendS7F1PPLoadInquire.Size = new System.Drawing.Size(268, 51);
            this.btnSendS7F1PPLoadInquire.TabIndex = 10;
            this.btnSendS7F1PPLoadInquire.Text = "Send S7F1 PP Load Inquire";
            this.btnSendS7F1PPLoadInquire.UseVisualStyleBackColor = false;
            this.btnSendS7F1PPLoadInquire.Click += new System.EventHandler(this.btnSendS7F1PPLoadInquire_Click);
            // 
            // btnSetPPFmtChanged
            // 
            this.btnSetPPFmtChanged.BackColor = System.Drawing.Color.White;
            this.btnSetPPFmtChanged.Location = new System.Drawing.Point(16, 75);
            this.btnSetPPFmtChanged.Name = "btnSetPPFmtChanged";
            this.btnSetPPFmtChanged.Size = new System.Drawing.Size(268, 51);
            this.btnSetPPFmtChanged.TabIndex = 9;
            this.btnSetPPFmtChanged.Text = "SetPPFmtChanged";
            this.btnSetPPFmtChanged.UseVisualStyleBackColor = false;
            this.btnSetPPFmtChanged.Click += new System.EventHandler(this.btnSetPPFmtChanged_Click);
            // 
            // btnSetPPChanged
            // 
            this.btnSetPPChanged.BackColor = System.Drawing.Color.White;
            this.btnSetPPChanged.Location = new System.Drawing.Point(16, 24);
            this.btnSetPPChanged.Name = "btnSetPPChanged";
            this.btnSetPPChanged.Size = new System.Drawing.Size(268, 51);
            this.btnSetPPChanged.TabIndex = 8;
            this.btnSetPPChanged.Text = "SetPPChanged";
            this.btnSetPPChanged.UseVisualStyleBackColor = false;
            this.btnSetPPChanged.Click += new System.EventHandler(this.btnSetPPChanged_Click);
            // 
            // tbSpool
            // 
            this.tbSpool.Controls.Add(this.rtbSpooling);
            this.tbSpool.Location = new System.Drawing.Point(4, 54);
            this.tbSpool.Name = "tbSpool";
            this.tbSpool.Padding = new System.Windows.Forms.Padding(3);
            this.tbSpool.Size = new System.Drawing.Size(1042, 379);
            this.tbSpool.TabIndex = 8;
            this.tbSpool.Text = "Spooling";
            this.tbSpool.UseVisualStyleBackColor = true;
            // 
            // rtbSpooling
            // 
            this.rtbSpooling.Location = new System.Drawing.Point(49, 34);
            this.rtbSpooling.Name = "rtbSpooling";
            this.rtbSpooling.Size = new System.Drawing.Size(378, 262);
            this.rtbSpooling.TabIndex = 4;
            this.rtbSpooling.Text = "";
            // 
            // tbpUserDefineMessage
            // 
            this.tbpUserDefineMessage.Controls.Add(this.btnS101F103);
            this.tbpUserDefineMessage.Controls.Add(this.btnS101F101);
            this.tbpUserDefineMessage.Location = new System.Drawing.Point(4, 54);
            this.tbpUserDefineMessage.Name = "tbpUserDefineMessage";
            this.tbpUserDefineMessage.Padding = new System.Windows.Forms.Padding(3);
            this.tbpUserDefineMessage.Size = new System.Drawing.Size(1042, 379);
            this.tbpUserDefineMessage.TabIndex = 9;
            this.tbpUserDefineMessage.Text = "User Define Message";
            this.tbpUserDefineMessage.UseVisualStyleBackColor = true;
            // 
            // btnS101F103
            // 
            this.btnS101F103.BackColor = System.Drawing.Color.White;
            this.btnS101F103.Location = new System.Drawing.Point(19, 75);
            this.btnS101F103.Name = "btnS101F103";
            this.btnS101F103.Size = new System.Drawing.Size(268, 51);
            this.btnS101F103.TabIndex = 11;
            this.btnS101F103.Text = "Send S101F103";
            this.btnS101F103.UseVisualStyleBackColor = false;
            this.btnS101F103.Click += new System.EventHandler(this.btnS101F103_Click);
            // 
            // btnS101F101
            // 
            this.btnS101F101.BackColor = System.Drawing.Color.White;
            this.btnS101F101.Location = new System.Drawing.Point(19, 24);
            this.btnS101F101.Name = "btnS101F101";
            this.btnS101F101.Size = new System.Drawing.Size(268, 51);
            this.btnS101F101.TabIndex = 10;
            this.btnS101F101.Text = "Send S101F101";
            this.btnS101F101.UseVisualStyleBackColor = false;
            this.btnS101F101.Click += new System.EventHandler(this.btnS101F101_Click);
            // 
            // lstMsg
            // 
            this.lstMsg.FormattingEnabled = true;
            this.lstMsg.HorizontalExtent = 2000;
            this.lstMsg.ItemHeight = 20;
            this.lstMsg.Location = new System.Drawing.Point(213, 1);
            this.lstMsg.Name = "lstMsg";
            this.lstMsg.ScrollAlwaysVisible = true;
            this.lstMsg.Size = new System.Drawing.Size(1023, 304);
            this.lstMsg.TabIndex = 13;
            this.lstMsg.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstMsg_MouseDoubleClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.m_btnXGemClose);
            this.groupBox1.Controls.Add(this.btnXGemInitialize);
            this.groupBox1.Controls.Add(this.btnXGemStop);
            this.groupBox1.Controls.Add(this.btnXGemStart);
            this.groupBox1.Controls.Add(this.tbCfgFileName);
            this.groupBox1.Location = new System.Drawing.Point(3, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(204, 185);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Initialize and Start";
            // 
            // m_btnXGemClose
            // 
            this.m_btnXGemClose.BackColor = System.Drawing.Color.White;
            this.m_btnXGemClose.Location = new System.Drawing.Point(18, 145);
            this.m_btnXGemClose.Name = "m_btnXGemClose";
            this.m_btnXGemClose.Size = new System.Drawing.Size(165, 27);
            this.m_btnXGemClose.TabIndex = 9;
            this.m_btnXGemClose.Text = "Close";
            this.m_btnXGemClose.UseVisualStyleBackColor = false;
            this.m_btnXGemClose.Click += new System.EventHandler(this.m_btnXGemClose_Click);
            // 
            // btnXGemInitialize
            // 
            this.btnXGemInitialize.BackColor = System.Drawing.Color.White;
            this.btnXGemInitialize.Location = new System.Drawing.Point(18, 64);
            this.btnXGemInitialize.Name = "btnXGemInitialize";
            this.btnXGemInitialize.Size = new System.Drawing.Size(165, 27);
            this.btnXGemInitialize.TabIndex = 8;
            this.btnXGemInitialize.Text = "Initialize";
            this.btnXGemInitialize.UseVisualStyleBackColor = false;
            this.btnXGemInitialize.Click += new System.EventHandler(this.btnXGemInitialize_Click);
            // 
            // btnXGemStop
            // 
            this.btnXGemStop.BackColor = System.Drawing.Color.White;
            this.btnXGemStop.Location = new System.Drawing.Point(18, 118);
            this.btnXGemStop.Name = "btnXGemStop";
            this.btnXGemStop.Size = new System.Drawing.Size(165, 27);
            this.btnXGemStop.TabIndex = 7;
            this.btnXGemStop.Text = "Stop";
            this.btnXGemStop.UseVisualStyleBackColor = false;
            this.btnXGemStop.Click += new System.EventHandler(this.btnXGemStop_Click);
            // 
            // btnXGemStart
            // 
            this.btnXGemStart.BackColor = System.Drawing.Color.White;
            this.btnXGemStart.Location = new System.Drawing.Point(18, 91);
            this.btnXGemStart.Name = "btnXGemStart";
            this.btnXGemStart.Size = new System.Drawing.Size(165, 27);
            this.btnXGemStart.TabIndex = 6;
            this.btnXGemStart.Text = "Start";
            this.btnXGemStart.UseVisualStyleBackColor = false;
            this.btnXGemStart.Click += new System.EventHandler(this.btnXGemStart_Click);
            // 
            // tbCfgFileName
            // 
            this.tbCfgFileName.Location = new System.Drawing.Point(18, 37);
            this.tbCfgFileName.Name = "tbCfgFileName";
            this.tbCfgFileName.Size = new System.Drawing.Size(165, 26);
            this.tbCfgFileName.TabIndex = 1;
            this.tbCfgFileName.Text = "Eq1.cfg";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btnCommunicationEnable);
            this.groupBox8.Controls.Add(this.btnCommunicationDisable);
            this.groupBox8.Controls.Add(this.tbCommState);
            this.groupBox8.Location = new System.Drawing.Point(3, 203);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(204, 127);
            this.groupBox8.TabIndex = 20;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Communication State";
            // 
            // btnCommunicationEnable
            // 
            this.btnCommunicationEnable.BackColor = System.Drawing.Color.White;
            this.btnCommunicationEnable.Location = new System.Drawing.Point(18, 60);
            this.btnCommunicationEnable.Name = "btnCommunicationEnable";
            this.btnCommunicationEnable.Size = new System.Drawing.Size(165, 27);
            this.btnCommunicationEnable.TabIndex = 10;
            this.btnCommunicationEnable.Text = "Enable";
            this.btnCommunicationEnable.UseVisualStyleBackColor = false;
            this.btnCommunicationEnable.Click += new System.EventHandler(this.btnCommunicationEnable_Click);
            // 
            // btnCommunicationDisable
            // 
            this.btnCommunicationDisable.BackColor = System.Drawing.Color.White;
            this.btnCommunicationDisable.Location = new System.Drawing.Point(18, 87);
            this.btnCommunicationDisable.Name = "btnCommunicationDisable";
            this.btnCommunicationDisable.Size = new System.Drawing.Size(165, 27);
            this.btnCommunicationDisable.TabIndex = 9;
            this.btnCommunicationDisable.Text = "Disable";
            this.btnCommunicationDisable.UseVisualStyleBackColor = false;
            this.btnCommunicationDisable.Click += new System.EventHandler(this.btnCommunicationDisable_Click);
            // 
            // tbCommState
            // 
            this.tbCommState.Enabled = false;
            this.tbCommState.Location = new System.Drawing.Point(18, 28);
            this.tbCommState.Name = "tbCommState";
            this.tbCommState.Size = new System.Drawing.Size(165, 26);
            this.tbCommState.TabIndex = 3;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btnReqHostOffline);
            this.groupBox9.Controls.Add(this.btnOffline);
            this.groupBox9.Controls.Add(this.btnLocal);
            this.groupBox9.Controls.Add(this.btnRemote);
            this.groupBox9.Controls.Add(this.tbControlState);
            this.groupBox9.Location = new System.Drawing.Point(3, 336);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(204, 181);
            this.groupBox9.TabIndex = 21;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Control State";
            // 
            // btnReqHostOffline
            // 
            this.btnReqHostOffline.BackColor = System.Drawing.Color.White;
            this.btnReqHostOffline.Location = new System.Drawing.Point(18, 141);
            this.btnReqHostOffline.Name = "btnReqHostOffline";
            this.btnReqHostOffline.Size = new System.Drawing.Size(165, 27);
            this.btnReqHostOffline.TabIndex = 14;
            this.btnReqHostOffline.Text = "HOST OFFLINE";
            this.btnReqHostOffline.UseVisualStyleBackColor = false;
            this.btnReqHostOffline.Click += new System.EventHandler(this.btnReqHostOffline_Click);
            // 
            // btnOffline
            // 
            this.btnOffline.BackColor = System.Drawing.Color.White;
            this.btnOffline.Location = new System.Drawing.Point(18, 57);
            this.btnOffline.Name = "btnOffline";
            this.btnOffline.Size = new System.Drawing.Size(165, 27);
            this.btnOffline.TabIndex = 11;
            this.btnOffline.Text = "OFFLINE";
            this.btnOffline.UseVisualStyleBackColor = false;
            this.btnOffline.Click += new System.EventHandler(this.btnOffline_Click);
            // 
            // btnLocal
            // 
            this.btnLocal.BackColor = System.Drawing.Color.White;
            this.btnLocal.Location = new System.Drawing.Point(18, 85);
            this.btnLocal.Name = "btnLocal";
            this.btnLocal.Size = new System.Drawing.Size(165, 27);
            this.btnLocal.TabIndex = 12;
            this.btnLocal.Text = "ONLINE LOCAL";
            this.btnLocal.UseVisualStyleBackColor = false;
            this.btnLocal.Click += new System.EventHandler(this.btnLocal_Click);
            // 
            // btnRemote
            // 
            this.btnRemote.BackColor = System.Drawing.Color.White;
            this.btnRemote.Location = new System.Drawing.Point(18, 113);
            this.btnRemote.Name = "btnRemote";
            this.btnRemote.Size = new System.Drawing.Size(165, 27);
            this.btnRemote.TabIndex = 13;
            this.btnRemote.Text = "ONLINE REMOTE";
            this.btnRemote.UseVisualStyleBackColor = false;
            this.btnRemote.Click += new System.EventHandler(this.btnRemote_Click);
            // 
            // tbControlState
            // 
            this.tbControlState.Enabled = false;
            this.tbControlState.Location = new System.Drawing.Point(18, 25);
            this.tbControlState.Name = "tbControlState";
            this.tbControlState.Size = new System.Drawing.Size(165, 26);
            this.tbControlState.TabIndex = 5;
            // 
            // tmrInfo
            // 
            this.tmrInfo.Tick += new System.EventHandler(this.tmrInfo_Tick);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.tbProcessingState);
            this.groupBox13.Controls.Add(this.m_cmbProcessingState);
            this.groupBox13.Controls.Add(this.btnProcessingState);
            this.groupBox13.Location = new System.Drawing.Point(3, 523);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(204, 174);
            this.groupBox13.TabIndex = 22;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "4. Processing State";
            // 
            // tbProcessingState
            // 
            this.tbProcessingState.Enabled = false;
            this.tbProcessingState.Location = new System.Drawing.Point(5, 123);
            this.tbProcessingState.Name = "tbProcessingState";
            this.tbProcessingState.Size = new System.Drawing.Size(177, 26);
            this.tbProcessingState.TabIndex = 16;
            // 
            // m_cmbProcessingState
            // 
            this.m_cmbProcessingState.FormattingEnabled = true;
            this.m_cmbProcessingState.Items.AddRange(new object[] {
            "1 - System Power Up",
            "2 - Empty",
            "3 - Idle",
            "4 - Standby",
            "5 - Processing",
            "6 - Hold Processing"});
            this.m_cmbProcessingState.Location = new System.Drawing.Point(6, 35);
            this.m_cmbProcessingState.Name = "m_cmbProcessingState";
            this.m_cmbProcessingState.Size = new System.Drawing.Size(177, 28);
            this.m_cmbProcessingState.TabIndex = 3;
            // 
            // btnProcessingState
            // 
            this.btnProcessingState.BackColor = System.Drawing.Color.White;
            this.btnProcessingState.Location = new System.Drawing.Point(5, 69);
            this.btnProcessingState.Name = "btnProcessingState";
            this.btnProcessingState.Size = new System.Drawing.Size(177, 48);
            this.btnProcessingState.TabIndex = 1;
            this.btnProcessingState.Text = "Processing State";
            this.btnProcessingState.UseVisualStyleBackColor = false;
            this.btnProcessingState.Click += new System.EventHandler(this.btnProcessingState_Click);
            // 
            // btnGetSv
            // 
            this.btnGetSv.BackColor = System.Drawing.Color.White;
            this.btnGetSv.Location = new System.Drawing.Point(68, 188);
            this.btnGetSv.Name = "btnGetSv";
            this.btnGetSv.Size = new System.Drawing.Size(165, 27);
            this.btnGetSv.TabIndex = 24;
            this.btnGetSv.Text = "Get SV";
            this.btnGetSv.UseVisualStyleBackColor = false;
            this.btnGetSv.Click += new System.EventHandler(this.btnGetSv_Click);
            // 
            // btnGetECV
            // 
            this.btnGetECV.BackColor = System.Drawing.Color.White;
            this.btnGetECV.Location = new System.Drawing.Point(258, 167);
            this.btnGetECV.Name = "btnGetECV";
            this.btnGetECV.Size = new System.Drawing.Size(181, 59);
            this.btnGetECV.TabIndex = 16;
            this.btnGetECV.Text = "Get ECV";
            this.btnGetECV.UseVisualStyleBackColor = false;
            this.btnGetECV.Click += new System.EventHandler(this.btnGetECV_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1264, 761);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lstMsg);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Equipment";
            this.tabControl1.ResumeLayout(false);
            this.tbGemRCmd.ResumeLayout(false);
            this.tbEvent.ResumeLayout(false);
            this.tbEvent.PerformLayout();
            this.tbpMaterialMovement.ResumeLayout(false);
            this.tbpMaterialMovement.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabTerminalServices.ResumeLayout(false);
            this.tabTerminalServices.PerformLayout();
            this.tabEquipmentConstants.ResumeLayout(false);
            this.tabEquipmentConstants.PerformLayout();
            this.tbVariableDataCollection.ResumeLayout(false);
            this.tbVariableDataCollection.PerformLayout();
            this.tbClock.ResumeLayout(false);
            this.tbpProcessProgram.ResumeLayout(false);
            this.tbSpool.ResumeLayout(false);
            this.tbpUserDefineMessage.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbGemRCmd;
        private System.Windows.Forms.TabPage tbEvent;
        private System.Windows.Forms.ListBox lstMsg;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button m_btnXGemClose;
        private System.Windows.Forms.Button btnXGemInitialize;
        private System.Windows.Forms.Button btnXGemStop;
        private System.Windows.Forms.Button btnXGemStart;
        private System.Windows.Forms.TextBox tbCfgFileName;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox tbCommState;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox tbControlState;
        private System.Windows.Forms.Button btnCommunicationEnable;
        private System.Windows.Forms.Button btnCommunicationDisable;
        private System.Windows.Forms.Button btnReqHostOffline;
        private System.Windows.Forms.Button btnOffline;
        private System.Windows.Forms.Button btnLocal;
        private System.Windows.Forms.Button btnRemote;
        private System.Windows.Forms.Label lbRcmdTitle;
        private System.Windows.Forms.RichTextBox rtbRcmdParam;
        private System.Windows.Forms.Button btnSendCEID112;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox tbALID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAlarmClear;
        private System.Windows.Forms.Button btnAlarmDetect;
        private System.Windows.Forms.TabPage tabTerminalServices;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbMessageFromHost;
        private System.Windows.Forms.TextBox tbTermialMessageTID;
        private System.Windows.Forms.Label lbSendTerminalMessageTitle;
        private System.Windows.Forms.TextBox tbSendTermialMessage;
        private System.Windows.Forms.Label lbTermialMessageTID;
        private System.Windows.Forms.Button mbtnTerminalMessageSend;
        private System.Windows.Forms.TabPage tabEquipmentConstants;
        private System.Windows.Forms.TextBox tbECV;
        private System.Windows.Forms.Button btnSetECV;
        private System.Windows.Forms.TextBox tbECID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox rtbNewEcv;
        private System.Windows.Forms.TabPage tbVariableDataCollection;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbVidName;
        private System.Windows.Forms.Button btnSetVariableByName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbVid;
        private System.Windows.Forms.TextBox tbVariableValue;
        private System.Windows.Forms.Button btnSetVariable;
        private System.Windows.Forms.TabPage tbClock;
        private System.Windows.Forms.Button btnReqHostGetDateTime;
        private System.Windows.Forms.Timer tmrInfo;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox m_cmbProcessingState;
        private System.Windows.Forms.Button btnProcessingState;
        private System.Windows.Forms.TabPage tbpProcessProgram;
        private System.Windows.Forms.Button btnSendS7F27PPFmtVerification;
        private System.Windows.Forms.Button btnSendS7F25FmtPPRequest;
        private System.Windows.Forms.Button btnSendS7F23FmtPPSend;
        private System.Windows.Forms.Button btnSendS7F5PPRequest;
        private System.Windows.Forms.Button btnSendS7F3PPSend;
        private System.Windows.Forms.Button btnSendS7F1PPLoadInquire;
        private System.Windows.Forms.Button btnSetPPFmtChanged;
        private System.Windows.Forms.Button btnSetPPChanged;
        private System.Windows.Forms.RichTextBox rtbClock;
        private System.Windows.Forms.TabPage tbSpool;
        private System.Windows.Forms.RichTextBox rtbSpooling;
        private System.Windows.Forms.Button btnSendCEID114;
        private System.Windows.Forms.Button btnSendCEID113;
        private System.Windows.Forms.RichTextBox rtbPP;
        private System.Windows.Forms.TextBox tbProcessingState;
        private System.Windows.Forms.TabPage tbpUserDefineMessage;
        private System.Windows.Forms.Button btnS101F103;
        private System.Windows.Forms.Button btnS101F101;
        private System.Windows.Forms.Button btnSendEvent124;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbVid1018;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbVid1019;
        private System.Windows.Forms.Button btnSetSv;
        private System.Windows.Forms.TabPage tbpMaterialMovement;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbVid33;
        private System.Windows.Forms.Button tbSetVid33;
        private System.Windows.Forms.Button tbSendCeid12;
        private System.Windows.Forms.Button tbSendCeid11;
        private System.Windows.Forms.Button btnGetSv;
        private System.Windows.Forms.Button btnGetECV;
    }
}

